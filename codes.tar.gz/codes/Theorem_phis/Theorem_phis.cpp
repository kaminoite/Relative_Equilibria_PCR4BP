#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

dim2taylor L2(int order, const interval& r, const interval& phi);
interval L2_div_r_with_diff(const interval& r, 
   const interval& phi, int dif);
interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Computing bounds from Lemma 3" << endl << endl;

   interval pi, C1, C2, C3, C4, C5;
   interval R0, alpha, cosalpha, Z0, d0, d2, d3, d4, h, df, m2, m1, m3, r;
   interval phi, phi1, phi3, phi4;
   interval bound_delta, bound_delta_prime;

   int i, N, flagerror;

   m1 = interval(0, 1)/interval(100);
   m2 = interval(0, 1)/interval(100);
   m3 = interval(1)-m1-m2;
   pi = atan(interval(1))*interval(4);
   alpha = atan(interval(1)); //alpha = pi/4
   cosalpha = cos(alpha);
   
   R0 = interval(1)/interval(1000);
   C1 = interval(100662)/interval(10000);
   C2 = interval(16665)/interval(1000);
   C3 = interval(454482)/interval(10000);
   C4 = interval(984105)/interval(10000);
   C5 = interval(173801)/interval(1000);
 
   cout << "#Constants:" << endl;
   cout << "   m_1 = " << m1 << endl;
   cout << "   m_2 = " << m2 << endl;
   cout << "   alpha = " << alpha << endl;
   cout << "   R_0 = " << R0 << endl;
   cout << "   D_1 = " << C1 << endl;
   cout << "   D_2 = " << C2 << endl;
   cout << "   D_3 = " << C3 << endl;
   cout << "   D_4 = " << C4 << endl;
   cout << "   D_5 = " << C5 << endl;
   cout << endl;

   cout << "#Checking inequality d_0(alpha, R) >= m2/m3*d_f(R) for all R\\in[0, R_0]" << endl;
   N = 100;
   flagerror = 0;
   for(i = 0; i < N; i++)
   {
      r = interval(i, i+1)/interval(N)*R0;
      d0 = interval(3)*cosalpha-interval(6)*r-sqr(r)*sqrt(sqr(C1)+sqr(C2));
      df = interval(3)+interval(6)*r+sqr(r)*(C1+C2);
      if(Inf(d0-m2/m3*df) < 0)
      {
         flagerror = 1;
         break;
      }
   }
   if(flagerror == 1)
   {
      cout << "   Error checking inequality" << endl;
   }else
   {
      cout << "   Inequality is true" << endl;
   }
   
   cout << endl;

   cout << "#Checking inequality |phi_0(0)-phi_0(R)|+m2/m3*Z_0(f, R)/(d_0(alpha, R) <= alpha/2 for all R\\in[0, R_0] " << 
   "and on all four curves" << endl;
   cout << endl;

   cout << "   #Curves phi_0(r)=0 and phi_0(r)=\\pi" << endl;

   N = 100;
   flagerror = 0;
   for(i = 0; i < N; i++)
   {
      r = interval(i, i+1)/interval(N)*R0;
      d0 = interval(3)*cosalpha-interval(6)*r-sqr(r)*sqrt(sqr(C1)+sqr(C2));
      Z0 = interval(3)/interval(2)+interval(5)/interval(2)*r+sqr(r)*C1;
      if(Inf(alpha/interval(2)-m2/m3*Z0/d0) < 0)
      {
         flagerror = 1;
         break;
      }
   }
   if(flagerror == 1)
   {
      cout << "      Error checking inequality" << endl;
   }else
   {
      cout << "      Inequality is true" << endl;
   }
   cout << endl;

   cout << "   #Curves phi_0(r)=\\pi/2+r/2+... and phi_0(r)=3\\pi/2-r/2+..." << endl;
   
   phi1 = interval(1)/interval(2);
   phi3 = interval(1)/interval(48);
   phi4 = interval(0, 12)/interval(10000);
   
   N = 100;
   flagerror = 0;
   for(i = 0; i < N; i++)
   {
      r = interval(i, i+1)/interval(N)*R0;

      phi = phi1*r+phi3*r*r*r+phi4*r*r*r*r;
      d0 = interval(3)*cosalpha-interval(6)*r-sqr(r)*sqrt(sqr(C1)+sqr(C2));
      Z0 = interval(3)/interval(2)+interval(5)/interval(2)*r+sqr(r)*C1;
      if(Inf(alpha/interval(2)-abs(phi)-m2/m3*Z0/d0) < 0)
      {
         flagerror = 1;
         break;
      }
   }
   if(flagerror == 1)
   {
      cout << "      Error checking inequality" << endl;
   }else
   {
      cout << "      Inequality is true" << endl;
   }
   cout << endl;
   
   cout << "# Bound for |delta|<=Z0(f0, R)/(m3 d0(alpha,R))" << endl;
   
   r = R0;
   d0 = interval(3)*cosalpha-interval(6)*r-sqr(r)*sqrt(sqr(C1)+sqr(C2));
   Z0 = interval(3)/interval(2)+interval(5)/interval(2)*r+sqr(r)*C1;
   bound_delta = Z0/(m3*d0);
   cout << "   " << Sup(bound_delta) << endl << endl;

   cout << "# Bound for |delta'|<=" << endl;
   df = interval(3)+interval(6)*r+sqr(r)*(C1+C2);
   d2 = interval(6)+interval(27)*r+sqr(r)*(C1+interval(2)*C2+C3);
   d3 = interval(5)/interval(2)+interval(2)*r*C1+sqr(r)*C4; 
   d4 = interval(6)+interval(2)*r*(C1+C2)+sqr(r)*(C4+C5);
   h = (d2*Z0/(m3*d0)+df/m3)/d0;
   if(Sup(h*m2) > 1)
   {
      cout << "   The bound can't be computed. h*m2 > 1!!!" << endl;
   }else
   {
      bound_delta_prime = (interval(1)+m2*h/(interval(1)-m2*h))/d0*(d4+d3/m3)+d3/d0*(h/(interval(1)-m2*h));
      cout << "   " << Sup(bound_delta_prime) << endl ;
      cout << "# Bound for |Delta'|=|delta'*m2|<=" << endl;
      cout << "   " << Sup(bound_delta_prime*m2) << endl << endl;
   }

   return 0;
}


