#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

dim2taylor L2(int order, const interval& r, const interval& phi);
dim2taylor L2_r(int order, const interval& r, const interval& phi);
interval L2_div_r_with_diff(const interval& r, const interval& phi, int dif);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Computing bounds from Lemma_gs" << endl;

   dim2taylor S, Sr;
   interval r, R, phi, aux0, aux1, aux2, aux3, aux4, alpha, pi, left, right;
   interval image0, image1, image2, image3, image4;
   real bound0, bound1, bound2, bound3, bound4;
   int i, j, M, order, N;

   N = 1000;
   M = 100;
   pi = atan(interval(1))*interval(4);
   alpha = atan(interval(1)); //alpha = pi/4

   R = interval(0, 1)/interval(1000);

   left = 0;
   right = interval(2)*pi;
   for(i = 0; i < N; i++)
   {
      //cout << i << " " << N << endl;
      for(j = 0; j < M; j++)
      {
         phi  = left+(right-left)*interval(i, i+1.)/interval(N);
         r = interval(j, j+1)/interval(M)*interval(Sup(R));

         S = L2(5, r, phi);
         Sr = L2_r(5, r, phi);
         aux0 = S[3][0];
         aux1 = S[3][1];
         aux2 = S[3][2]*interval(2);
         aux3 = Sr[3][0]-interval(3)*S[4][0];
         aux4 = Sr[3][1]-interval(3)*S[4][1];
         /*cout << S << endl;
         cout << aux0 << endl;
         cout << aux1 << endl;
         cout << aux2 << endl;
         cout << aux3 << endl;
         cout << aux4 << endl;*/
         if(i == 0 && j == 0)
         {
            image0 = aux0;
            image1 = aux1;
            image2 = aux2;
            image3 = aux3;
            image4 = aux4;
         }else
         {
            image0 = image0|aux0;
            image1 = image1|aux1;
            image2 = image2|aux2;
            image3 = image3|aux3;
            image4 = image4|aux4;
         }
      }
   }
   cout << image0 << endl;
   cout << image1 << endl;
   cout << image2 << endl;
   cout << image3 << endl;
   cout << image4 << endl;
   
   bound0 = abs(Sup(image0));
   if(bound0 < abs(Inf(image0)))
   {
      bound0 = abs(Inf(image0));
   }
   bound1 = abs(Sup(image1));
   if(bound1 < abs(Inf(image1)))
   {
      bound1 = abs(Inf(image1));
   }
   bound2 = abs(Sup(image2));
   if(bound2 < abs(Inf(image2)))
   {
      bound2 = abs(Inf(image2));
   }
   bound3 = abs(Sup(image3));
   if(bound3 < abs(Inf(image3)))
   {
      bound3 = abs(Inf(image3));
   }
   bound4 = abs(Sup(image4));
   if(bound4 < abs(Inf(image4)))
   {
      bound4 = abs(Inf(image4));
   }

   cout << "|g| <= " << bound0 << endl;
   cout << "|d_phi g| <= " << bound1 << endl;
   cout << "|d_{phi,phi} g| <= " << bound2 << endl;
   cout << "|d_{r} g| <= " << bound3 << endl;
   cout << "|d_{r,phi} g| <= " << bound4 << endl;
   return 0;
}

dim2taylor L2(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   //r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));
   r3 = sqrt(1+2*tv[1]*cos(tv[2])+sqr(tv[1]));

   //res = sqr(tv[1])/interval(2)+tv[1]*cos(tv[2])+interval(1)/r3;
   res = interval(1)-interval(1)/(r3*r3*r3)-interval(3)*cos(tv[2])*tv[1]-sqr(tv[1])*(interval(3)*sqr(sin(tv[2]))/interval(2)-interval(6)*sqr(cos(tv[2])));

   return res;
}

dim2taylor L2_r(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   //r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));
   r3 = sqrt(1+2*tv[1]*cos(tv[2])+sqr(tv[1]));

   //res = sqr(tv[1])/interval(2)+tv[1]*cos(tv[2])+interval(1)/r3;
   res = interval(3)/interval(2)/(sqr(sqr(r3))*r3)-interval(3)*cos(tv[2])-interval(2)*tv[1]*(interval(3)*sqr(sin(tv[2]))/interval(2)-interval(6)*sqr(cos(tv[2])));

   return res;
}


interval L2_div_r_with_diff(const interval& r, 
   const interval& phi, int dif)
{
   dim2taylor res;
   interval res2;

   res = remove_and_shift(diff(L2(1+3+dif, r, phi), 0, dif), 1, 3);

   res2 = res[0][0];
   
   return res2;
}

