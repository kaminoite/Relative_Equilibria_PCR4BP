#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

int main(int argc, char* argv[])
{
   cout << SetPrecision(7, 5);
   
   cout << endl << "#Computing bounds for the eigenvalues "
      "under the assumption that m1 <= 1/2" << endl;

   interval m2, m3, l1, l2, deltam, diff;
   real l1min, l1max, l2min, l2max, diffmin, diffmax;
   real maxdiam;
   int i, j, N;
   
   N = 3000;

   l1min = 1000;
   l1max = -1000;
   l2min = 1000;
   l2max = -1000;
   diffmin = 1000;
   diffmax = -1000;

   maxdiam = 0;
   for(i = 0; i < N; i++)
   {
      m2 = interval(1)+interval(i, i+1)/interval(N)*(interval(1)/interval(100)-interval(1));
      for(j = 0; j < N; j++)
      {
         m3 = interval(1)+interval(j, j+1)/interval(N)*(interval(1)/interval(100)-interval(1));
         if(Sup(m3) < Inf(m2))
         {
            continue;
         }
         if(Inf(m2+m3) > 1)
         {
            continue;
         }
         if(Sup(interval(2)*(m2+m3)) < 1)
         {
            continue;
         }

         l1 = (interval(2)+m2+m3+interval(3)*sqrt(sqr(m2+m3)-interval(3)*m2*m3))/interval(2);
         l2 = (interval(2)+m2+m3-interval(3)*sqrt(sqr(m2+m3)-interval(3)*m2*m3))/interval(2);
         if(diam(l1) > maxdiam)
         {
            maxdiam = diam(l1);
         }
         if(diam(l2) > maxdiam)
         {
            maxdiam = diam(l2);
         }
         diff = interval(3)*sqrt(sqr(m2+m3)-interval(3)*m2*m3);
         if(diffmin > Inf(diff))
         {
            diffmin = Inf(diff);
         }
         if(l1min > Inf(l1))
         {
            l1min = Inf(l1);
         }
         if(l2min > Inf(l2))
         {
            l2min = Inf(l2);
         }
         if(diffmax < Sup(diff))
         {
            diffmax = Sup(diff);
         }
         if(l1max < Sup(l1))
         {
            l1max = Sup(l1);
         }
         if(l2max < Sup(l2))
         {
            l2max = Sup(l2);
         }
      }
   }
   cout << "min l1 " << l1min << endl;
   cout << "max l1 " << l1max << endl;
   cout << "min l2 " << l2min << endl;
   cout << "max l2 " << l2max << endl;
   cout << "min l1-l2 " << diffmin << endl;
   cout << "max l1-l2 " << diffmax << endl;
   cout << "max diam " << maxdiam << endl;

   return 0;
}
