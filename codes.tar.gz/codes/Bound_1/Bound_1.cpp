#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "itaylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

itaylor r3(int order, const interval& r, const interval& phi);
itaylor one_minus_one_div_r3_cube(int order, const interval& r, 
   const interval& phi);
itaylor phi_0_plus(int order, const interval& r, const interval& phi);
itaylor phi_0_plus_x(int order, const interval& r, const interval& phi);
itaylor phi_0_minus(int order, const interval& r, const interval& phi);
itaylor phi_0_minus_x(int order, const interval& r, const interval& phi);
itaylor quotient_1(int order, const interval& r, const interval& phi);
itaylor quotient_2(int order, const interval& r, const interval& phi);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Computing Bound 1" << endl << endl;

   itaylor rr;
   interval res, r, phi, aux, pi, leftr, leftphi, rightr, rightphi;
   int i, j, order, N, flag_validity;

   N = 100;
   pi = atan(interval(1))*interval(4);

   leftphi = interval(0);
   rightphi = interval(2)*pi;
   leftr = interval(0);
   rightr = interval(1)/interval(10);
   
   order = 4;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = r3(order, r, phi);
         aux = rr[4];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "r3(r,phi)[4] \\in " << res << endl << endl;

   order = 4;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = one_minus_one_div_r3_cube(order, r, phi);
         aux = rr[4];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "(1-1/r3(r,phi)^3)[4] \\in " << res << endl << endl;

   order = 4;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = phi_0_plus(order, r, phi);
         aux = rr[4];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "phi_0_plus(r)[4] \\in " << res << endl << endl;

   order = 3;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = phi_0_plus_x(order, r, phi);
         aux = rr[3];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "diff(phi_0_plus)(r)[3] \\in " << res << endl << endl;

   order = 4;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = phi_0_minus(order, r, phi);
         aux = rr[4];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "phi_0_minus(r)[4] \\in " << res << endl << endl;

   order = 3;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = phi_0_minus_x(order, r, phi);
         aux = rr[3];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "diff(phi_0_minus)(r)[3] \\in " << res << endl << endl;

   order = 5;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = quotient_1(order, r, phi);
         aux = rr[5];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "(r*(3+3*r+r*r)/(1+r)^2)[5] \\in " << res << endl << endl;

   order = 5;
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      phi  = leftphi+(rightphi-leftphi)*interval(i, i+1.)/interval(N);
      for(j = 0; j < N; j++)
      {
         r  = leftr+(rightr-leftr)*interval(j, j+1.)/interval(N);
         rr = quotient_2(order, r, phi);
         aux = rr[5];
         if(j == 0 && i == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }
   cout << "(r*(3-3*r+r*r)/(1-r)^2)[5] \\in " << res << endl << endl;

   cout << endl;

   return 0;
}

itaylor r3(int order, const interval& r, const interval& phi)
{
   itaylor res, r3;
   itaylor x(order, r);

   r3 = sqrt(interval(1)+interval(2)*x*cos(phi)+sqr(x));

   res = r3;

   return res;
}

itaylor one_minus_one_div_r3_cube(int order, const interval& r, 
   const interval& phi)
{
   itaylor res, r3;
   itaylor x(order, r);
   
   r3 = sqrt(interval(1)+interval(2)*x*cos(phi)+sqr(x));

   res = interval(1)-interval(1)/(sqr(r3)*r3);

   return res;
}

itaylor phi_0_plus(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = acos(-x/interval(2));

   return res;
}

itaylor phi_0_plus_x(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = interval(1)/sqrt(interval(4)-sqr(x));

   return res;
}

itaylor phi_0_minus(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = acos(x/interval(2));

   return res;
}

itaylor phi_0_minus_x(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = interval(-1)/sqrt(interval(4)-sqr(x));

   return res;
}

itaylor quotient_1(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = x*(interval(3)+interval(3)*x+sqr(x))/sqr(interval(1)+x);

   return res;
}

itaylor quotient_2(int order, const interval& r, const interval& phi)
{
   itaylor res;
   itaylor x(order, r);
   
   res = x*(interval(3)-interval(3)*x+sqr(x))/sqr(interval(1)-x);

   return res;
}

