#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"
#include "itaylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

interval evaluate_itaylor(const itaylor& V, const interval& x);
itaylor V0_r_phi2(const itaylor& r, const itaylor& phi);
itaylor V0_r_phi(const itaylor& r, const itaylor& phi);
itaylor V1_r_phi(const itaylor& r, const itaylor& phi);
itaylor V2_r_phi(const itaylor& r, const itaylor& phi);
itaylor V1_r(const itaylor& r, const itaylor& phi);
itaylor V2_r(const itaylor& r, const itaylor& phi);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Existence results \\partial_r V(r, phi(r)):" << endl << endl;

   dim2taylor VV;
   itaylor phi0, r2, r3, aux_it;
   itaylor coef_m2, coef_m1, coef_0;
   itaylor coef_m1m2, coef_m2m2;
   itaylor x;
   interval delta;
   interval r, phi, m1, m2, pi;
   int order;

   pi = atan(interval(1))*interval(4);

   r = interval(0, 1)/interval(1000);
   m1 = interval(0, 1)/interval(100);
   m2 = interval(0, 1)/interval(100);
   delta = interval(-1, 1)*interval(724802)/interval(1000000);
   //r = interval(0);
   //delta = interval(0);

   cout << "#Constants:" << endl;
   cout << "   R = " << r << endl;
   cout << "   m1 = " << m1 << endl;
   cout << "   m2 = " << m2 << endl;
   cout << "   delta = " << delta << endl << endl;
   
   cout << "#Bounds for phi_0(r)=pi/2+r/2+r^3/48+";
   cout << "[ 0., 0.00119]r^4" << endl;
   
   cout << "   coef m1 = 1*r" << endl;
   cout << "   coef m2 = 9/4*r+";

   x = itaylor(2, r);
   r2 = sqrt(interval(1)-sqr(x)/interval(2)-x*sqrt(interval(3))
      *sqrt(interval(1)-sqr(x)/interval(4))+sqr(x));

   coef_m2 = -x*x*sqrt(interval(1)-sqr(x)/interval(4))/interval(2)*delta;
   
   aux_it = -sqrt(interval(1)-sqr(x)/interval(4))*sqrt(interval(3))/interval(2)
      *(interval(1)-interval(1)/(r2*r2*r2))
      +x/interval(4)*(interval(1)+interval(1)/(r2*r2*r2))-
      x/(r2*r2*r2)+x/interval(2);
  
   coef_m2 = coef_m2+aux_it;
   
   cout << coef_m2[2] << "*r^2" << endl;

   x = itaylor(1, r);
   phi0 = pi/interval(2)+x/interval(2)+sqr(x)*x/interval(48)+sqr(sqr(x))*interval(0, 119)/interval(100000)
      +interval(-1, 1)*m2*delta;
   coef_m1m2 = V1_r_phi(x, phi0)*delta;
   cout << "   coef m1m2 = " << coef_m1m2[1] << "*r" << endl;

   coef_m2m2 = V0_r_phi2(x, phi0)*sqr(delta)/interval(2)+V2_r_phi(x, phi0)*delta;
   cout << "   coef m2m2 = " << coef_m2m2[1] << "*r" << endl;
   cout << "   #Contained in" << endl;
   cout << "   m1*r+" << interval(9)/interval(4)+r*coef_m2[2]+m2*coef_m2m2[1]+m1*coef_m1m2[1] << "m2*r" << endl;
   cout << endl;


   cout << "#Bounds for phi_0(r)=3pi/2-r/2-r^3/48-";
   cout << "[ 0., 0.00119]r^4" << endl;
   
   cout << "   coef m1 = 1*r" << endl;
   cout << "   coef m2 = 9/4*r+";

   x = itaylor(2, r);
   r2 = sqrt(interval(1)-sqr(x)/interval(2)+x*sqrt(interval(3))
      *sqrt(interval(1)-sqr(x)/interval(4))+sqr(x));

   coef_m2 = x*x*sqrt(interval(1)-x*x/interval(4))/interval(2)*delta;
   
   aux_it = sqrt(interval(1)-x*x/interval(4))*sqrt(interval(3))/interval(2)
      *(interval(1)-interval(1)/(r2*r2*r2))
      +x/interval(4)*(interval(1)+interval(1)/(r2*r2*r2))-
      x/(r2*r2*r2)+x/interval(2);
  
   coef_m2 = coef_m2+aux_it;
   
   cout << coef_m2[2] << "*r^2" << endl;

   x = itaylor(1, r);
   phi0 = interval(3)*pi/interval(2)-x/interval(2)-sqr(x)*x/interval(48)-sqr(sqr(x))*interval(0, 119)/interval(100000)
      +interval(-1, 1)*m2*delta;
   coef_m1m2 = V1_r_phi(x, phi0)*delta;
   cout << "   coef m1m2 = " << coef_m1m2[1] << "*r" << endl;

   coef_m2m2 = V0_r_phi2(x, phi0)*sqr(delta)/interval(2)+V2_r_phi(x, phi0)*delta;
   cout << "   coef m2m2 = " << coef_m2m2[1] << "*r" << endl;
   cout << "   #Contained in" << endl;
   cout << "   m1*r+" << interval(9)/interval(4)+r*coef_m2[2]+m2*coef_m2m2[1]+m1*coef_m1m2[1] << "m2*r" << endl;
   cout << endl;
   
   cout << "#Bounds for phi_0(r)=0" << endl;
   
   order = 2;
   x = itaylor(order, r);
   phi = interval(0);
   r3 = sqrt(interval(1)+interval(2)*x*cos(phi)+sqr(x));
   coef_0 = (x+cos(phi))*(interval(1)-interval(1)/(r3*r3*r3));
   cout << "   coef_0 = 3*r+" << coef_0[2] << "*r^2" << endl;

   x = itaylor(1, r);
   phi0 = phi+interval(-1, 1)*m2*delta;
   coef_m1 = V1_r(x, phi0);
   cout << "   coef m1 = " << coef_m1[1] << "*r" << endl;

   coef_m2 = V0_r_phi(x, phi0)*delta+V2_r(x, phi0);
   cout << "   coef m2 = " << coef_m2[1] << "*r" << endl;
   cout << "   #Contained in" << endl;
   cout << interval(3)+r*coef_0[2] << "r+"<< coef_m1[1] << "m1*r+" << coef_m2[1] << "m2*r" << endl;
   cout << endl;

   cout << "#Bounds for phi_0(r)=pi" << endl;
   
   order = 2;
   x = itaylor(order, r);
   phi = pi;
   r3 = sqrt(interval(1)+interval(2)*x*cos(phi)+sqr(x));
   coef_0 = (x+cos(phi))*(interval(1)-interval(1)/(r3*r3*r3));
   cout << "   coef_0 = 3*r+" << coef_0[2] << "*r^2" << endl;

   x = itaylor(1, r);
   phi0 = phi+interval(-1, 1)*m2*delta;
   coef_m1 = V1_r(x, phi0);
   cout << "   coef m1 = " << coef_m1[1] << "*r" << endl;

   coef_m2 = V0_r_phi(x, phi0)*delta+V2_r(x, phi0);
   cout << "   coef m2 = " << coef_m2[1] << "*r" << endl;
   cout << "   #Contained in" << endl;
   cout << interval(3)+r*coef_0[2] << "r+"<< coef_m1[1] << "m1*r+" << coef_m2[1] << "m2*r" << endl;
   cout << endl;

   return 0;
}

itaylor V0_r_phi2(const itaylor& r, const itaylor& phi)
{
   itaylor res, r3;

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = -cos(phi)+cos(phi)/(r3*r3*r3)
      +(interval(3)*r*sqr(sin(phi))-r*cos(phi)*(cos(phi)+r)
      +r*sqr(sin(phi)))/(r3*r3*r3*r3*r3)
      +(interval(5)*sqr(r*sin(phi))*(cos(phi)+r))/(r3*r3*r3*r3*r3*r3*r3);

   return res;
}


itaylor V0_r_phi(const itaylor& r, const itaylor& phi)
{
   itaylor res, r3;

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = -sin(phi)*(interval(1)-interval(1)/(r3*r3*r3))-r*sin(phi)*
      (cos(phi)+r)/(r3*r3*r3*r3*r3);

   return res;
}

itaylor V1_r_phi(const itaylor& r, const itaylor& phi)
{
   return -V0_r_phi(r, phi);
}

itaylor V2_r_phi(const itaylor& r, const itaylor& phi)
{
   itaylor res, phi2;
   interval pi;

   pi = atan(interval(1))*interval(4);
   phi2 = phi+pi/interval(3);
   res = -V0_r_phi(r, phi)+V0_r_phi(r, phi2);

   return res;
}

itaylor V1_r(const itaylor& r, const itaylor& phi)
{
   itaylor res, r3;

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+sqr(r));

   res = -cos(phi)+(r+cos(phi))/(r3*r3*r3);
   
   return res;
}


itaylor V2_r(const itaylor& r, const itaylor& phi)
{
   itaylor res, r2, r3;
   interval pi;

   pi = atan(interval(1))*interval(4);

   r2 = sqrt(interval(1)+interval(2)*r*cos(phi+pi/interval(3))+sqr(r));
   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+sqr(r));

   res = -sqrt(interval(3))/interval(2)*sin(phi)
      *(interval(1)-interval(1)/(r2*r2*r2))-cos(phi)/interval(2)*
      (interval(1)+interval(1)/(r2*r2*r2))-r/(r2*r2*r2)+(cos(phi)+r)/
      (r3*r3*r3);

   return res;
}

interval evaluate_itaylor(const itaylor& V, const interval& x)
{
   itaylor VV;
   interval res, xi;
   int i;

   VV = V;
   res = interval(0);
   xi = interval(1);
   for(i = 0; i <= VV.order(); i++)
   {
      res = res+VV[i]*xi;
      xi = xi*(x-x);
   }

   return res;
}
