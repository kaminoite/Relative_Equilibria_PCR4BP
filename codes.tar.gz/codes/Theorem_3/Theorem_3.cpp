#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

dim2taylor f0_times_r(int order, const interval& r, const interval& phi);
dim2taylor f0_with_diff(int order, const interval& r, 
   const interval& phi, int diff1, int diff2);
interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y);
interval compute_M(const interval& R, int diff1, int diff2);
interval h(const interval& R, const interval& C1, const interval& C2, 
   const interval& C3, const interval& Z0, const interval& d0, 
   const interval& df, const interval& m3);
interval h2(const interval& R, const interval& C1, const interval& C2, 
   const interval& C3, const interval& Z0, const interval& d0, 
   const interval& df, const interval& m2, const interval& m3);
int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Theorem 3: Computing bounds" << endl << endl;

   // The constants come from code LEMMA_2
   interval C1, C2, C3;
   interval m1, m2, m3, pi, alpha, r, R, Z0, d0, df;
   interval phi0, phiR, aux;
   interval H2, M1, M2, M3, deltahat, delta;
   real Z0_real, d0_real, df_real, h_real, h2_real;

   C1 = interval(17);
   C2 = interval(32);
   C3 = interval(77);

   pi = atan(interval(1))*interval(4);
   alpha = pi/interval(4);

   m1 = interval(0, 1)/interval(100);
   m2 = interval(0, 1)/interval(100);
   m3 = interval(1)-m1-m2;
   
   R = interval(1)/interval(100);

   Z0_real = Sup(interval(3)/interval(2)+interval(10)*R+R*R*C1);
   d0_real = Inf(interval(3)*cos(alpha)-interval(30)*R-R*R*(C1+C2));
   df_real = Sup(interval(3)+interval(30)*R+R*R*(C1+C2));

   Z0 = interval(Z0_real);
   d0 = interval(d0_real);
   df = interval(df_real);

   if(Inf(d0) > Sup(m2/m3*df))
   {
      cout << "d_0(alpha, R1) > m2/m3*df(R_1) is true." << endl << endl;
   }

   cout << "phi_0(r) = 0:" << endl;

   if(Sup(m2/m3*Z0/d0) < Inf(alpha/interval(2)))
   {
      cout << "\t OK." << endl;
   }else
   {
      cout << "Failed." << endl;
   }

   cout << "phi_0(r) = pi:" << endl;

   if(Sup(m2/m3*Z0/d0) < Inf(alpha/interval(2)))
   {
      cout << "\t OK." << endl;
   }else
   {
      cout << "Failed." << endl;
   }

   cout << "phi_0(r) = pi/2+r/2+r^3/48+r^4[0, 0.0001171998]:" << endl;

   aux = interval(Sup(abs(R/interval(2)+
      R*R*R/interval(48)+R*R*R*R*interval(0, 12)/interval(100000))))
      +m2/m3*Z0/d0;
   if(Sup(aux) < Inf(alpha/interval(2)))
   {
      cout << "\t OK." << endl;
   }else
   {
      cout << "Failed." << endl;
   }

   cout << "phi_0(r) = 3pi/2-r/2-r^3/48+r^4[-0.0001171998, 0]:" << endl;

   aux = interval(Sup(abs(R/interval(2)+
      R*R*R/interval(48)+R*R*R*R*interval(0, 12)/interval(100000))))
      +m2/m3*Z0/d0;
   if(Sup(aux) < Inf(alpha/interval(2)))
   {
      cout << "\t OK." << endl;
   }else
   {
      cout << "Failed." << endl;
   }

   cout << endl;

   delta = interval(Inf(Z0/m3*d0));
   cout << "\t |delta| <=" << Inf(Z0/m3*d0) << endl << endl;
   
   H2 = h2(R, C1, C2, C3, Z0, d0, df, m2, m3);
   M1 = compute_M(R, 0, 1);
   M2 = compute_M(R, 1, 1);
   M3 = compute_M(R, 1, 0);
   deltahat = (M1+m2*H2)*(m2*delta+M3/m3)+H2*M3;

   cout << "\t |delta'| <= " << Inf(deltahat) << endl << endl;

   cout << endl;

   return 0;
}

dim2taylor f0_times_r(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));

   res = -sin(tv[1])*(interval(1)-interval(1)/(r3*r3*r3));

   return res;
}

dim2taylor f0_with_diff(int order, const interval& r, 
   const interval& phi, int diff1, int diff2)
{
   dim2taylor res, r3, r2, res2;

   res = diff(f0_times_r(order+1+diff1+diff2, r, phi), diff1, diff2);

   res2 = remove_and_shift(res, 1, 1);

   return res2;
}

interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y)
{
   interval res(0), xi, yj;
   int i, j;

   xi = interval(1);
   yj = interval(1);
   for(i = 0; i <= V.order(); i++)
   {
      yj = interval(1);
      for(j = 0; j <= V.order()-i; j++)
      {
         res = res+V[i][j]*xi*yj;
         yj = yj*(y-y);
      }
      xi = xi*(x-x);
   }

   return res;
}

interval compute_M(const interval& R, int diff1, int diff2)
{
   int i, j;
   interval res, r, phi, pi2, aux;
   dim2taylor V;
   int N, order;

   N = 100;
   order = 4;

   pi2 = atan(interval(1))*interval(8);
   res = interval(0);
   for(i = 0; i < N; i++)
   {
      r = interval(i, i+1)/interval(N)*R;
      for(j = 0; j < N; j++)
      {
         phi = interval(j, j+1)/interval(N)*pi2;
         V = f0_with_diff(order, r, phi, diff1, diff2);
         aux = evaluate_dim2taylor(V, r, phi);
         if(i == 0 && j == 0)
         {
            res = aux;
         }else
         {
            res = res|aux;
         }
      }
   }

   aux = res;

   res = interval(abs(Sup(aux)));
   if(abs(Inf(aux)) > abs(Sup(aux)))
   {
      res = interval(abs(Inf(aux)));
   }
   return res;
}

interval h(const interval& R, const interval& C1, const interval& C2, 
   const interval& C3, const interval& Z0, const interval& d0, 
   const interval& df, const interval& m3)
{
   interval res;
   interval d2;

   d2 = interval(6)+interval(75)*R+R*R*(C1+interval(2)*C2+C3);

   res = (d2*Z0/(m3*d0)+df)*d0;

   return interval(Sup(res));
}

interval h2(const interval& R, const interval& C1, const interval& C2, 
   const interval& C3, const interval& Z0, const interval& d0, 
   const interval& df, const interval& m2, const interval& m3)
{
   interval res, aux;
   interval H;

   H = h(R, C1, C2, C3, Z0, d0, df, m3);

   aux = interval(1)-m2*H;

   if(Inf(aux) < 0)
   {
      cerr << "Error computing h2 " << endl << endl;
   }
   
   res = H/aux; 

   return interval(Sup(res));
}
