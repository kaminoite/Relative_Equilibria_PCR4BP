#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

dim2taylor h(int order, const interval& x, const interval& y, 
   const interval& m2, const interval& m3);
interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y);

int main(int argc, char* argv[])
{
   cout << SetPrecision(7, 5);
   
   cout << endl << "#Computing bounds for h" << endl;

   dim2taylor H;
   interval x, y, m2, m3;
   int order;

   x = interval(-1, 1)/interval(1000);
   y = interval(-1, 1)/interval(1000);
   m2 = interval(0, 1)/interval(2);
   m3 = interval(0, 3)/interval(3);
  
   order = 5;
   H = h(order, x, y, m2, m3);

   cout << H << endl;

   interval res;
   int i, j, k, l, N;
   real aux, maxC1, maxC2;

   N = 1000;
   maxC1 = 0.;
   maxC2 = 0.;
   for(k = 0; k < N; k++)
   {
      cout << "loop = " << k << " of " << N << endl;
      m2 = interval(k, k+1)/interval(2*N); 
      for(l = 0; l < N; l++)
      {
         m3 = interval(1)/interval(3)+interval(l, l+1)/interval(N)*interval(2)/interval(3);
         order = 5;
         H = h(order, x, y, m2, m3);

         res = interval(0);
         for(i = 0; i < order+1; i++)
         {
            for(j = 0; j < order+1; j++)
            {
               if(i+j == 3)
               {
                  res = res+abs(H[i][j]);
               }
            }
         }
         aux = Sup(abs(interval(3)*res));
         if(maxC1 < aux)
         {
            maxC1 = aux;
         }
         aux = Sup(abs(interval(6)*res));
         if(maxC2 < aux)
         {
            maxC2 = aux;
         }
      }
   }
   cout << "C1 <= " << maxC1 << endl;
   cout << "C2 <= " << maxC2 << endl;

   return 0;
}

dim2taylor h(int order, const interval& x, const interval& y, 
   const interval& m2, const interval& m3)
{
   dim2taylor res;
   dim2taylor_vector tv;
   ivector iv(2);
   ivector p1(2), p2(2), p3(2);

   p1[1] = sqrt(interval(3))/interval(2);
   p1[2] = interval(1)/interval(2);
   p2[1] = sqrt(interval(3))/interval(2);
   p2[2] = -interval(1)/interval(2);
   p3[1] = interval(0);
   p3[2] = interval(0);
 
   iv[1] = x;
   iv[2] = y;

   tv = init_var(order, iv);
 
   res = m2/sqrt(sqr(p1[1]+tv[1]-p2[1])+sqr(p1[2]+tv[2]-p2[2]))+
      m3/sqrt(sqr(p1[1]+tv[1]-p3[1])+sqr(p1[2]+tv[2]-p3[2]));
 
   int i, j;
   for(i = 0; i < 3; i++)
   {
      for(j = 0; j < 3; j++)
      {
         if(i+j > 2)
         {
            continue;
         }
         res[i][j] = interval(0.);
      }
   }

   return res;
}

dim2taylor h_diff(int order, const interval& x, 
   const interval& y, const interval& m2, const interval& m3, 
   int diff1, int diff2)
{
   dim2taylor res;

   res = diff(h(order+diff1+diff2, x, y, m2, m3), diff1, diff2);

   return res;
}

interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y)
{
   interval res(0), xi, yj;
   int i, j;

   xi = interval(1);
   yj = interval(1);
   for(i = 0; i <= V.order(); i++)
   {
      yj = interval(1);
      for(j = 0; j <= V.order()-i; j++)
      {
         res = res+V[i][j]*xi*yj;
         yj = yj*(y-y);
      }
      xi = xi*(x-x);
   }

   return res;
}
