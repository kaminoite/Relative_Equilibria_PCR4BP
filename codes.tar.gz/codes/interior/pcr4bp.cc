/*   File: pcr4bp.cc

     Main source code for the PCR4BP computations.
     
     Attempts to establish that a region in configuration*mass-space
     undergoes no bifurcations. We do this by verifying that either
       
       1. F(X,M) != 0 (no solutions)
     or
       2. det(DF(X,M)) != 0, i.e., g' != 0 (no bifurcations).

     The point is that when we know that there are no bifurcations, then
     we know that the number of solutions is constant.
     
     When this is not enough, we try to unveil deeper bifurcations by 
     verifying that either
     
       3. g''(X;M) != 0    [a 2nd order (2 -> 0) bifurcation]
     or
       4. g'''(X;M) != 0   [a 3rd order (3 -> 1) bifurcation].
     
     At the same time, we check for 1. and 2.  
     
     We are working on the PCR4BP with masses 
     
				0 <= m1 <= m2 <= m3 <= 1 and (m4 = 0) with m1 + m2 + m3 = 1. 
			 
	We use the reparametrization 
		  
				t = m1 + m2 and s = m1/t 
		 
	in order to treat small masses more efficiently. The smallest rectangular
	domain is (s,t) \in [0, 1/2]x[0, 2/3]. 

    We are working in polar coordinates (r,a): the search region
    is taken to be 
     
				r \in [1/3, 2] and a \in [-\pi, \pi]. 
		 
    The bounds for r are theoretical. We avoid the singularities at the
    primaries p1 and p2 (r,a) = (1, +-pi/6) by using two different
    near distance checks that rule out solutions near p1 and p2. 
	
				(0 < m_1 <= 1e-2) and (|z - p_1| <= 1e-4) => no bifurcations.

	The degenerate case when both m1 and m2 are zero is taken care of by
    a desingularization of the potential. Otherwise we would have an
    entire circle of solutions. 

    Syntax ex (with timings)

				./pcr4bp 1e-6 0.45 0.45 0.60 0.60 1   [10 solutions]
				./pcr4bp 1e-6 0.00 0.50 0.58 0.67 2   [0m02s]

				./pcr4bp 1e-6 0.25 0.25 0.25 0.25 1   [8 solutions]
				./pcr4bp 1e-6 0.00 1e-6 0.00 1e-6 2   [0m01s]
				./pcr4bp 1e-6 1e-6 0.50 0.00 1e-6 2   [1m30s]
				./pcr4bp 1e-6 0.00 1e-6 1e-6 0.55 2   [7m40s]
				./pcr4bp 1e-6 1e-6 0.50 1e-6 0.55 2   [1m38s]

				./pcr4bp 1e-6 0.00 0.20 0.55 0.58 3   [0m02s]
				./pcr4bp 1e-6 0.20 0.25 0.55 0.58 3   [4m53s]
				./pcr4bp 1e-6 0.25 0.50 0.55 0.58 3   [0m43s]				
                
     Author: Warwick Tucker
     Email : warwick.tucker@monash.edu
     Latest edit: Fri 04 Feb 2022 17:27:21 AEDT
*/

#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <fstream>
#include <unistd.h> 
#include "capd/capdlib.h"
#include "interval_extras.h"
#include "potential_functions.h"
#include "utilities.h"

using namespace capd;
using namespace std;
using capd::autodiff::Node;

typedef capd::vectalg::Vector<double, 0>   RVector;    //  vector
typedef capd::vectalg::Matrix<double, 0,0> RMatrix;    //  matrix

#include "list.h"

#undef OUTPUT_COMPILE_INFO	  
#define OUTPUT_COMPILE_INFO	  
#undef  FULL_OUTPUT        // Print debug info.
//#define FULL_OUTPUT
#undef  PRINT_LISTS        // Store various list data.
//#define PRINT_LISTS
#undef  PRINT_GN_LISTS     // Store g^(n) list data.
//#define PRINT_GN_LISTS
#undef  SOME_OUTPUT        // Print some info and list data.
//#define SOME_OUTPUT

//----------------------------------------------------------------------
// Checks if m1 <= m2 <= m3.
//
bool massesAreOrdered(const IVector &XP)
{
  	interval s = XP(3);
  	interval t = XP(4);
	// Added 220221 by WT.    
	if ( Inf(t*(2-s)) > 1.0 ) // Here m2 > m3.
		return false;
	return true;
	
	// The above version should be better than below.
	// m1 <= m2 always as long as s <= 1/2.

  	interval m1 = s*t;
  	interval m2 = (1 - s)*t;
  	interval m3 = 1 - t;
  	if ( Inf(m2) > Sup(m3) ) // m2 > m3.
    	return false;	
  	if ( Inf(m1) > Sup(m2) ) // m1 > m2.
    	return false;	  
  	return true;  
}

//----------------------------------------------------------------------
// The interval Krawczyk operator.
//
bool krawczyk(IVector &K, const IVector &X, const IVector &P)
{
  	IVector midX = midVector(X);
  	IMatrix invDFmidX(2,2);
	if ( !inverse2x2(invDFmidX, DF(midX, P)) )
	  	return false;
	IMatrix I(2,2); 
	I(1,1) = interval(1);I(1,2) = interval(0);
	I(2,1) = interval(0);I(2,2) = interval(1);
	K = midX - invDFmidX*F(midX, P) + (I - invDFmidX*DF(X, P))*(X - midX);
	return true;
}

//----------------------------------------------------------------------
// An iterative search using Krawczyk.
//
int krawczykSearch(IVector &K_oldX, const IVector &X, const IVector &P)
{
  	IVector    newX = X; 
  	bool rootUnique = false;
  	int i = 0;
  	int maxIter = 10;
  	while( !rootUnique && (i < maxIter)) {
    	IVector oldX = newX;
    	if ( !krawczyk(K_oldX, oldX, P) ) {
      		return 4; // Singular matrix DF(midX).
    	} 
    	if( !Intersection(newX, K_oldX, oldX) ) { // Check for empty intersection.
      		return 1; // No zero in X.
		}
    	if ( subsetInterior(K_oldX,oldX) ) { 
      		rootUnique = true;
      		return 2; // Unique zero in oldX and K_oldX.
		}
		i++;
  	}
  	K_oldX = newX;
  	return 3;     // Undetermined: intersection, but no strict inclusion.
}

//----------------------------------------------------------------------
// Tightens a proven enclosure with Krawczyk.
//
IVector tighten(const IVector &X, const IVector &P, int maxIter)
{
	IVector oldX = X;
	IVector newX = X;
	for (int i = 1; i<= maxIter; i++) {
    	krawczyk(newX, oldX, P);
    	oldX = newX;
  	}
	return newX;
}

//----------------------------------------------------------------------
// Bisection interlaced with Krawczyk. Note: we only use this for thin
// parameter sets, i.e., no bisection is performed in (s,t)-coordinates.
// If successful, we return the number of solutions, otherwise -1.
int countSolutions(List<IVector> &workList, double TOL)
{
	RVector wX(4); wX(1) = 1.0; wX(2) = 1.0; wX(3) = 0.0; wX(4) = 0.0;
	List<IVector> yesList, smallList, noList, tightList, ndtList;
	IVector XP  = First(workList);
  	IVector P(2); P(1) = XP(3); P(2) = XP(4);
  	// Start a hybrid search procedure over workList.
  	while( !IsEmpty(workList) ) {  
		XP = Pop(workList);
		IVector X(2); X(1) = XP(1); X(2) = XP(2);	
		if ( maxDiam(X) < TOL )                   // Too small to examine further. 
			smallList += XP;
		else {
		    if ( !nearDistanceTest(XP) )          // Start with this test.
				ndtList += XP;
			else {                                // Passed the near distance test.
				if ( containsPrimaries(XP) )
				  	splitAndStore(XP, workList, wX);// Split and re-examine.
				else {                            // Safe to evaluate F.
		    		if ( subset(0.0, F(XP)) ) {   // Still a potential candidate.
			      		IVector KX = X;
						int code = krawczykSearch(KX, X, P);
						if ( code == 1)           // No zero in X.
							noList += XP;
						else if ( code == 2 ) {   // A unique zero in X.
							yesList += XP;
							X = tighten(KX, P, 5);// Five additional iterations.
							XP(1) = X(1); XP(2) = X(2);
							tightList += XP;      // A tight enclosure of a zero.
						} 
						else if ( code >= 3 )     // Undetermined status or singular
							splitAndStore(XP, workList, wX);// matrix in the Krawczyk operator.
					}
					else
						noList += XP;             // Certainly rejected domain.
				}
			}
		}
	}

	cout << "After bisection/Krawczyk stage:" << endl
    	 << "  |smallList|  : " << Length(smallList) << endl
       	 << "  |noList|     : " << Length(noList) << endl
         << "  |yesList|    : " << Length(yesList) << endl
         << "  |tightList|  : " << Length(tightList) << endl
         << "  |ndtList|    : " << Length(ndtList) << endl; 
#ifdef PRINT_LISTS        
  	printMyList(smallList  , "list_small.txt"); 
  	printMyList(noList     , "list_no.txt");  
  	printMyList(yesList    , "list_yes.txt");  
  	printMyList(tightList  , "list_tight.txt");  
  	printMyList(ndtList    , "list_ndt.txt");  
#endif

	if ( IsEmpty(smallList) )
	  	return Length(tightList);
	return -1;
}

//----------------------------------------------------------------------
// Bisection in XP-space to find degenerate and non-degenerate regions.
// smallList will contain all degenerate regions (if any) on termination.
//
bool zoomInOnDegenerate(List<IVector> &workList, double TOL)
{
	List<IVector> smallList, noList, ndgList, ndtList;
  	int unorderedMassCounter = 0;
  	while( !IsEmpty(workList) ) {  
		IVector XP = Pop(workList);                
		if ( massesAreOrdered(XP) ) {            // Enforce m1 <= m2 <= m3. 
			if ( maxDiam(XP) < TOL ) {           // Too small to examine further. 
				smallList += XP;                 // Could be a degenerate region.
				cerr << "Too small XP = " << XP << endl;
				exit(0);
			}	
			else if ( !nearDistanceTest(XP) ) {  // Start with this test.
				ndtList += XP;
			}
			else if ( containsPrimaries(XP) ) {
				splitAndStore(XP, workList);     // Split and re-examine.
			} 
			else if ( subset(0.0, F(XP)) ) {     // Still a potential candidate.
				interval detDF = det2x2(DF(XP));
				if ( !subset(0.0, detDF) )       // Non-degenerate; save.
					ndgList += XP;
				else
					splitAndStore(XP, workList); // Split and re-examine.
			}                                    // This splitting is special!
			else
			  	noList += XP;                    // Certainly rejected domain.
		}
    else
      	unorderedMassCounter++;
	}

  	cout << "After bisection/determinant stage:" << endl
         << "  unordered masses: " << unorderedMassCounter << endl
         << "  |smallList|     : " << Length(smallList) << endl
         << "  |noList|        : " << Length(noList) << endl
         << "  |ndgList|       : " << Length(ndgList) << endl 
         << "  |ndtList|       : " << Length(ndtList) << endl;        

#ifdef PRINT_LISTS             
  	printMyList(smallList , "list_small.txt");  
  	printMyList(noList    , "list_no.txt" );  
  	printMyList(ndgList   , "list_ndg.txt");  
  	printMyList(ndtList   , "list_ndt.txt");
#endif
    
  	if ( unorderedMassCounter > 0 )
    	cout << "NOTE: we encountered regions in parameter space that " << endl
        	 << "correspond to unordered masses. These were not analyzed." << endl;
         
	if ( IsEmpty(smallList) )
	  	return true; // Conclusive
	return false;	 // Inconclusive
}

//----------------------------------------------------------------------
// Counts the number of connected components of a list of boxes in
// configuration space. We are assuming that there can be at most three
// connected components. If not, we warn of failure, and return -1.
// If successful, we return the cc:s in comp[1,2,3]List, and their number.
//
int connectedComponents(List<IVector> &workList, List<IVector> &comp1List, 
                        List<IVector> &comp2List, List<IVector> &comp3List)
{
	List<IVector> currentList, nextList, storeList;	
	
	if ( Length(workList) == 0 )
	  return 0; // No connected component.

	// Check for a first component.
	currentList += Pop(workList);
	while ( !IsEmpty(currentList) ) {
		IVector XPtop = Pop(currentList);
		while( !IsEmpty(workList) ) {  
			IVector XPnew = Pop(workList); 
			if ( !emptyIntersection(XPtop(1), XPnew(1)) && !emptyIntersection(XPtop(2), XPnew(2)) ) 
				nextList += XPnew;
			else
			  storeList += XPnew;
		}
		comp1List += XPtop;
	  	while ( !IsEmpty(storeList) ) // Move back for the next pass.
			workList += Pop(storeList);	
		while ( !IsEmpty(nextList) )  // Move back for the next pass.
		 	currentList += Pop(nextList);	
	}
	if ( Length(workList) == 0 ) {
		First(comp1List);
		while ( !Finished(comp1List) ) { // Copy back the input list.
			workList += Current(comp1List);
			Next(comp1List);
		}		
	  return 1;                        // One connected component.
  }
  
	// Check for a second component.
	currentList += Pop(workList);
	while ( !IsEmpty(currentList) ) {
		IVector XPtop = Pop(currentList);
		while( !IsEmpty(workList) ) {  
			IVector XPnew = Pop(workList); 
			if ( !emptyIntersection(XPtop(1), XPnew(1)) && !emptyIntersection(XPtop(2), XPnew(2)) ) 
				nextList += XPnew;
			else
				storeList += XPnew;
		}
		comp2List += XPtop;
	  	while ( !IsEmpty(storeList) )    // Move back for the next pass.
			workList += Pop(storeList);	
		while ( !IsEmpty(nextList) )     // Move back for the next pass.
		 	currentList += Pop(nextList);	
	}
	if ( Length(workList) == 0 ) {
		First(comp1List);
		while ( !Finished(comp1List) ) { // Copy back the input list.
			workList += Current(comp1List);
			Next(comp1List);
		}		
		First(comp2List);
		while ( !Finished(comp2List) ) { // Copy back the input list.
			workList += Current(comp2List);
			Next(comp2List);
		}		
	  return 2;                          // Two connected components.
  }
  
  	// Check for a third component.
	currentList += Pop(workList);
	while ( !IsEmpty(currentList) ) {
		IVector XPtop = Pop(currentList);
		while( !IsEmpty(workList) ) {  
			IVector XPnew = Pop(workList); 
			if ( !emptyIntersection(XPtop(1), XPnew(1)) && !emptyIntersection(XPtop(2), XPnew(2)) ) 
				nextList += XPnew;
			else
				storeList += XPnew;
		}
		comp3List += XPtop;
	  	while ( !IsEmpty(storeList) ) // Move back for the next pass.
			workList += Pop(storeList);	
		while ( !IsEmpty(nextList) )  // Move back for the next pass.
			currentList += Pop(nextList);	
	}
	if ( Length(workList) == 0 ) {
		First(comp1List);
		while ( !Finished(comp1List) ) { // Copy back the input list.
			workList += Current(comp1List);
			Next(comp1List);
		}		
		First(comp2List);
		while ( !Finished(comp2List) ) { // Copy back the input list.
			workList += Current(comp2List);
			Next(comp2List);
		}		
		First(comp3List);
		while ( !Finished(comp3List) ) { // Copy back the input list.
			workList += Current(comp3List);
			Next(comp3List);
		}		
	  	return 3;                        // Three connected components.
  	}	

#ifdef FULL_OUTPUT  
	cerr << "Failure in 'connectedComponents'." << endl;			 
	cerr << "Reason: there are more than three connected components!!!" << endl;
#endif
	return -1;
}   
                    
//----------------------------------------------------------------------
// Computes an upper bound of the number of solutions via standard 
// bisection combined with a bifurcation analysis. Returns -1 on failure;
// we then split in parameter space and redo the computations.
//
int numberOfSolutions(int &solutionType, const IVector &XP, IMap &adF, 
					  IMap &adDF, double TOL_B)
{
	List<IVector> workList, gnList, g0List, g1List, g1pList, g2List, g3List, smallList;
	int unorderedMassCounter(0);
 	// Split only in configuration space
  	RVector wX(4); wX(1) = 1.0; wX(2) = 1.0; wX(3) = 0.0; wX(4) = 0.0; 

  	double TOL_A(1e-3); // Carefully selected!
 
  	workList += XP;
  	while( !IsEmpty(workList) ) {  
		IVector XP = Pop(workList);  
		IVector X(2); X(1) = XP(1); X(2) = XP(2);
		if ( !massesAreOrdered(XP) ) 
		{ // Enforce m1 <= m2 <= m3.          
			unorderedMassCounter++;           
		}
		else if ( !nearDistanceTest(XP) )   
		{ // Try to exlude regions due to the near distance tests.
		  gnList += XP;		
		} 
		else if ( containsPrimaries(XP) )
		{ // Avoid singularities at the two lighter primaries p1 and p2. 
			splitAndStore(XP, workList, wX);    
		}                          
		else if ( !subset(0.0, F(XP)) ) 
		{ // Not a critical point; save.
			g0List += XP; 
		} 
		else if ( maxDiam(X) > TOL_A )
		{ // Enforce norm < TOL_A before exploring deeper.
			splitAndStore(XP, workList, wX); 
		}
		else if ( nonZeroD0F(XP, TOL_B) )
		{ // A recursive, deep trial for F(XP) != 0.
			g0List += XP; 
		}
		else if ( nonZeroDetDF(XP, TOL_B) )
		{ // A recursive, deep trial for det(DF(XP)) != 0.
			g1List += XP; 
		}
		else if ( nonZeroD2G(XP, TOL_B, adF, adDF) )  
		{ // A recursive, deep trial for g''(XP) != 0.
			g2List += XP; 
		}
		else if ( nonZeroD3G(XP, TOL_B, adF, adDF) )
		{ // A recursive, deep trial for g'''(XP) != 0.
			g3List += XP; 
		}	
		else
		{ // Failure!
#ifdef FULL_OUTPUT  			
			cerr << "Failure in 'numberOfSolutions'!" << endl;
			cerr << "Try selecting other values for TOL_A and TOL_B." << endl;
#endif			
			return -1;
		}		
	}
#ifdef FULL_OUTPUT  
  	cout << "After bisection/bifurcation stage:" << endl
         << "  unordered masses: " << unorderedMassCounter << endl
         << "  max |workList|  : " << MaxLength(workList) << endl
         << "  |gnList|        : " << Length(gnList) << endl
         << "  |g0List|        : " << Length(g0List) << endl
         << "  |g1List|        : " << Length(g1List) << endl      
         << "  |g2List|        : " << Length(g2List) << endl
         << "  |g3List|        : " << Length(g3List) << endl;
#endif

#ifdef PRINT_GN_LISTS
  	printMyList(gnList, "list_gn.txt"); 
  	printMyList(g0List, "list_g0.txt"); 
  	printMyList(g1List, "list_g1.txt"); 
  	printMyList(g2List, "list_g2.txt"); 
  	printMyList(g3List, "list_g3.txt");  
#endif			     

  	List<IVector> totList, c1List, c2List, c3List;
  
  	// Copy all lists into totList.
  	if ( !IsEmpty(g1List) ) {
		First(g1List);
		while( !Finished(g1List) ) {
			totList += Current(g1List);
		  	Next(g1List);
		}
	}
	if ( !IsEmpty(g2List) ) {
		First(g2List);
		while( !Finished(g2List) ) {
			totList += Current(g2List);
		  	Next(g2List);
		}
	}
	if ( !IsEmpty(g3List) ) {
		First(g3List);
		while( !Finished(g3List) ) {
			totList += Current(g3List);
			Next(g3List);
		}
	}
	
	// Get the connected components of totList: at most three.
	int cc = connectedComponents(totList, c1List, c2List, c3List);
#ifdef FULL_OUTPUT  
  	cout << "After connected component stage: cc = " << cc << endl
    	 << "  |totList|       : " << Length(totList) << endl
       	 << "  |c1List|        : " << Length(c1List) << endl      
         << "  |c2List|        : " << Length(c2List) << endl
         << "  |c3List|        : " << Length(c3List) << endl;
#endif	
	if ( cc == 1 ) { // One single connected component, in c1List.
	    if ( nonZeroDetDF(c1List, TOL_B) ) {
			solutionType = 100;
		  	return 1; 
		} 
		if ( nonZeroD3G(c1List, TOL_B, adF, adDF) ) { 	
			// Verify that these regions carry at most one f2=0 level set.					  
			if ( exactly_two_intersections(Hull(c1List)) ) {
			}
			else {
				return -1;
			}	
			// Verify that these regions carry at least one sol.
			if ( atLeastOneSol(c1List) ) {
			//	cout << "Confirmed a zero throughout the component." << endl;
			}
			else {
				return -1;
			}	
			solutionType = 300;
			return 3;
		}
		// If we can't prove either case, we give up.
    	return -1; 
	}
	if ( cc == 2 ) { // Two connected components, in c1List and c2List.
		IVector hull_c1 = Hull(c1List);
		IVector hull_c2 = Hull(c2List);
		IVector cap;
		if ( Intersection(cap, hull_c1, hull_c2) ) {
			return -1;
		}
		if ( nonZeroDetDF(c1List, TOL_B) && nonZeroD2G(c2List, TOL_B, adF, adDF) ) {
			// Verify that these regions carry at most one f2=0 level set.					  
			if ( exactly_two_intersections(hull_c2) ) {
			//	cout << "Confirmed a unique f2 = 0 level throughout the component." << endl;
			}
			else {
				return -1;
			}	
			solutionType = 210;	
		  	return 3;
		}
		if ( nonZeroDetDF(c2List, TOL_B) && nonZeroD2G(c1List, TOL_B, adF, adDF) ) {
			// Verify that these regions carry at most one f2=0 level set.					  
			if ( exactly_two_intersections(hull_c1) ) {
			//	cout << "Confirmed a unique f2 = 0 level throughout the component." << endl;
			}
			else {
				return -1;
			}
			solutionType = 210;
		  	return 3; 
		}
		// If we can't prove a 1+2 or a 2+1 situation, we give up.
		return -1; 
	}
	if ( cc == 3 ) { // Three connected components, in c1List, c2List, and c3List.
		if ( nonZeroDetDF(c1List, TOL_B) && nonZeroDetDF(c2List, TOL_B) && nonZeroDetDF(c3List, TOL_B) ) {
			solutionType = 111;
		  	return 3;
		}
		// If we can't prove a 1+1+1 situation, we give up.
		return -1; 
	}
	// Could not get a suitible number of connected components.
	return -1;
}

//----------------------------------------------------------------------
// Initializes and loads the three outer search regions in configuration space.
//
void setThreeInitialSearchDomains(List<IVector> &workList, const IVector &P)
{
	cout << "Searching the following three outer regions of configuration space:" << endl;	
	interval IV_PI = interval::pi();
	// Add the three main initial regions.
  	IVector XP(2*DIM);           // Configuration-and mass-space together.
  	XP(3) = P(1);
  	XP(4) = P(2);      
  	IVector X(DIM);  
  	X(1) = interval(0.3333333, 2.0); // 1/3 from Lemma 3 in the manuscript.
  	X(2) = interval(0.7,Sup(IV_PI));
  	cout << "  C1 = " << X << endl;  
  	XP(1) = X(1);
  	XP(2) = X(2);
  	workList += XP;
 
  	X(2) = interval(-Sup(IV_PI), -0.2);
  	cout << "  C2 = " << X << endl;  
  	XP(1) = X(1);
  	XP(2) = X(2);     
  	workList += XP;  
 
  	X(1) = interval(1.0, 2.0);
  	X(2) = interval(-0.2, 0.7);
  	cout << "  C3 = " << X << endl;
  	XP(1) = X(1);
  	XP(2) = X(2);  
  	workList += XP;
}

//----------------------------------------------------------------------
// Initializes and loads the one inner search region in configuration space.
//
void setOneInitialSearchDomain(List<IVector> &workList, const IVector &P)
{
  	cout << "Searching the single, inner region of configuration space:" << endl;
	interval IV_PI = interval::pi();
  	IVector XP(2*DIM);           // Configuration-and mass-space together.
  	XP(3) = P(1);
  	XP(4) = P(2);      
  	IVector X(DIM);  
  	X(1) = interval(0.3333333, 1.0); // 1/3 from Lemma 3 in the manuscript.
  	X(2) = interval(-0.2, 0.7);
  	cout << "  C0 = " << X << endl;  
  	XP(1) = X(1);
  	XP(2) = X(2);
  	workList += XP;
}

//----------------------------------------------------------------------
// Initializes and loads the total configuration space.
//
void setFullInitialSearchDomain(List<IVector> &workList, const IVector &P)
{
  	cout << "Searching the full configuration space:" << endl;
	interval IV_PI = interval::pi();
  	IVector XP(2*DIM);           // Configuration-and mass-space together.
  	XP(3) = P(1);
  	XP(4) = P(2);      
  	IVector X(DIM);  
  	X(1) = interval(0.3333333, 2.0); // 1/3 from Lemma 3 in the manuscript.
  	X(2) = interval(-1,1)*IV_PI;
  	cout << "  C = " << X << endl;  
  	XP(1) = X(1);
  	XP(2) = X(2);
  	workList += XP;
}

//----------------------------------------------------------------------
// Full run searching for bifurcations of type 2->0 and 3->1 taking 
// place within the equilateral triangle of the three primaries. 
//
bool performBifurcationAnalysis(List<IVector> &workList, double MIN_TOL_P)
{
	IVector XP = First(workList);
	IVector P(2); P(1) = XP(3); P(2) = XP(4);
 	// Set up the AD engines needed for befurcation analysis.
  	interval pi_sixths = interval::pi()/interval(6.0);
	int dimIn=2, dimOut=2, dimParam=3, derivDepth=3;
	IMap adF(F_AD,dimIn,dimOut,dimParam,derivDepth);

	adF.setParameter(0,P(1));  // Will be partitioned later.
	adF.setParameter(1,P(2));  // Will be partitioned later.
	adF.setParameter(2,pi_sixths);
  
  	dimIn=2, dimOut=4, dimParam=3, derivDepth=2;
	IMap adDF(DF_AD,dimIn,dimOut,dimParam,derivDepth);
  	adDF.setParameter(0,P(1));  // Will be partitioned later.
	adDF.setParameter(1,P(2));  // Will be partitioned later.
	adDF.setParameter(2,pi_sixths);
	
	bool unorderedMassesFound(false);
	
 	RVector wP(4); wP(1) = 0.0; wP(2) = 0.0; wP(3) = 0.75; wP(4) = 1.0; 
	double MAX_TOL_P = 5e-2; // Sufficiently small parameter regions.  
	    
	List<IVector> smallList, s0List, s1List, s2List, s3List; 
 	List<IVector> s300List, s210List, s111List;

 	cout << "Splitting tolerances for parameters: [" << MIN_TOL_P 
 	     << ", " << MAX_TOL_P << "]." << endl;
  
  	while ( !IsEmpty(workList) ) {
    	IVector XP = Pop(workList);
    	if ( massesAreOrdered(XP) ) {
			IVector P(2); P(1) = XP(3); P(2) = XP(4);
			if ( (maxDiam(P) > MAX_TOL_P) ) {	  // Pre-split the parameter space.
	      		splitAndStore(XP, workList, wP);
			}
	    	else {
				if ( maxDiam(P) < MIN_TOL_P ) {   // This should never happen.
					smallList += XP;              // We return false if it does.
				}
				else {
					double MIN_TOL_X = 0.1*maxDiam(P);  // Added by WT 211222.
					int solutionType(0);         // More info when ns == 3.
				  	int ns = numberOfSolutions(solutionType, XP, adF, adDF, MIN_TOL_X);
				  	if ( (ns < 0) || (3 < ns) )  // Not successful; split and redo.
				    	splitAndStore(XP, workList, wP);
				  	else if ( ns == 1 )          // No bifurcations.
				    	s1List += XP;
				  	else if ( ns == 2 )          // Should never happen.
				    	s2List += XP;
				  	else if ( ns == 3 ) {        // At most three solutions.
						s3List += XP;
					  	if ( solutionType == 300 ) // 3 -> 1 bifurcation.
					    	s300List += XP;
					  	if ( solutionType == 210 ) // 2 -> 0 bifurcation + 1.
					    	s210List += XP;
					  	if ( solutionType == 111 ) // 3 isolated solutions.
					    	s111List += XP;       	   
					} 
				}
		  	}
		}
	  	else {                             // All unordered masses.
      		unorderedMassesFound = true;
      		s0List += XP;
		}		  
#ifdef SOME_OUTPUT
    	if ( (Length(workList) % 1000) == 0 ) {    
			cout << " |workList| = " << Length(workList)
		         << " |smallList| = " << Length(smallList) 
           		 << " |s0List| = " << Length(s0List) 
           		 << " |s1List| = " << Length(s1List) 
           		 << " |s2List| = " << Length(s2List) 
           		 << " |s3List| = " << Length(s3List)
            	 << " |s111List| = " << Length(s111List) 
           		 << " |s210List| = " << Length(s210List) 
           		 << " |s300List| = " << Length(s300List) << endl; 	           
			printMyList(workList, "list_work.txt"); 
			printMyList(smallList, "list_small.txt"); 
			printMyList(s0List, "list_s0.txt"); 
			printMyList(s1List, "list_s1.txt");    
			printMyList(s2List, "list_s2.txt"); 
			printMyList(s3List, "list_s3.txt");  
			printMyList(s111List, "list_s111.txt");    
			printMyList(s210List, "list_s210.txt"); 
			printMyList(s300List, "list_s300.txt");  			
		}
#endif		     
	}  // End of the entire search.
  	cout << "After the bisection/bifurcation stage:" << endl
		 << "  |smallList|: " << Length(smallList) << endl
	     << "  |s0List|   : " << Length(s0List) << endl 
	     << "  |s1List|   : " << Length(s1List) << endl 
	     << "  |s2List|   : " << Length(s2List) << endl 
	     << "  |s3List|   : " << Length(s3List) << endl
	     << "  |s111List| : " << Length(s111List) << endl 
	     << "  |s210List| : " << Length(s210List) << endl 
	     << "  |s300List| : " << Length(s300List) << endl; 
	if ( IsEmpty(smallList) ) {
		if ( !IsEmpty(s3List) )
			cout << "There are subregions of C0 with at most three solutions." << endl;
		if ( !IsEmpty(s2List) )
			cout << "There are subregions of C0 with at most two solutions." << endl;
		if ( !IsEmpty(s1List) )
			cout << "There are subregions of C0 with at most one solution." << endl;
	} 
#ifdef PRINT_LISTS	
	printMyList(smallList, "list_small.txt"); 
  	printMyList(s0List, "list_s0.txt"); 
  	printMyList(s1List, "list_s1.txt");    
  	printMyList(s2List, "list_s2.txt"); 
  	printMyList(s3List, "list_s3.txt");  
  	printMyList(s111List, "list_s111.txt");    
	printMyList(s210List, "list_s210.txt"); 
	printMyList(s300List, "list_s300.txt"); 
#endif  	
	if ( unorderedMassesFound )
    	cout << "NOTE: we encountered regions in parameter space that " << endl
        	 << "correspond to unordered masses. These were not analyzed." << endl;
	if ( IsEmpty(smallList) )
	  	return true; // Conclusive
	return false;	 // Inconclusive
}

//----------------------------------------------------------------------
//
int main(int argc, char * argv[]) 
{
#ifdef OUTPUT_COMPILE_INFO	  
	char hostname[1024];
	gethostname(hostname, 1024);
	time_t curr=time(0);
	
  cout << endl
       << "============================================================" 
       << endl
       << "========================== pcr4bp =========================="
       << endl
       << "Latest compilation: " << __DATE__ << ", " << __TIME__ << endl
       << "Running on host '" << hostname << "'." << endl 
	   << "Started computations: " << ctime(&curr) << endl;	  		   
#endif			 
	// Default parameters for the main run.
  	double TOL  = 1e-4;      // Splitting tolerance in XP-space.
  	double MIN_TOL_P = 1e-8; // Minimal splitting in P-space.
  	double sMin = 0.0;       // s = m1/t  
  	double sMax = 0.5;       // s = m1/t
  	double tMin = 0.0;       // t = m1 + m2
  	double tMax = 2.0/3;     // t = m1 + m2
  	int search_tactic = 3;   // Bifurcation analysis.
  
  	// User parameters for the main run.
  	if (argc >= 2)
    	TOL = atof(argv[1]);
  	if (argc >= 4) {
    	sMin = atof(argv[2]);
    	sMax = atof(argv[3]);		
		if ( sMin > sMax ) {
			cerr << "Wrong input: sMin > sMax." << endl;
			return 0;
		}
	}  
  	if (argc >= 6) {
    	tMin = atof(argv[4]);
    	tMax = atof(argv[5]);
		if ( tMin > tMax ) {
			cerr << "Wrong input: tMin > tMax." << endl;
			return 0;
		}
	}
	if (argc == 7 )
	  	search_tactic = atoi(argv[6]);
	  
 	IVector P(DIM);
	P(1) = interval(sMin, sMax); P(2) = interval(tMin, tMax);
	
	// Print the parameters used for the main run. 
	cout.setf(ios::scientific);
	cout.setf(ios::showpos);
	cout.setf(ios::right);
  	cout << "Stopping tolerance in the search: TOL = " << TOL << endl;
  	cout << "Parameter range for s = [" << Inf(P(1)) << ", " << Sup(P(1)) << "]" << endl;
  	cout << "Parameter range for t = [" << Inf(P(2)) << ", " << Sup(P(2)) << "]" << endl;
  	cout << "  This corresponds to " << endl;
  	cout << "  m1 = " << P(1)*P(2) << endl;
  	cout << "  m2 = " << (1-P(1))*P(2) << endl;
  	cout << "  m3 = " << 1-P(2) << endl;
  
  	// Start the main search/analysis.
  	int ns(0); // The (maximal) number of solutions.
  	bool successful_search(false);
  	List<IVector> workList;
  
  	switch(search_tactic) {
		case 1 :  // Exact count.
			cout << "=========================================================" << endl
			     << "Using strategy #1: Trying to get an exact count valid for" << endl
			     << "the entire parameter region." << endl 
                 << "=========================================================" << endl;    
		  	// Add the full search region in configuration-mass-space.
	    	setFullInitialSearchDomain(workList, P);
			ns = countSolutions(workList, TOL);
			if ( ns > 0 ) {
				cout << "=========================================================" << endl
			         << "SUCCESS: the explicit search was conclusive." << endl
			         << "We found exactly " << ns << " solutions." << endl
			         << "=========================================================" << endl;
			}
			else {
				cout << "=========================================================" << endl
			         << "FAILURE: the explicit search was inconclusive." << endl 
			         << "=========================================================" << endl;
			}
  		
      	break;
    	case 2 :  // No bifurcations.
      		cout << "=========================================================" << endl 
				 << "Using strategy #2: Trying to prove that no bifurcations  " << endl
			 	 << "take place for the entire parameter region. " << endl
            	 << "=========================================================" << endl;     
      		// Add the full search region in configuration-mass-space. 
			setFullInitialSearchDomain(workList, P);
			successful_search = zoomInOnDegenerate(workList, TOL);
			if ( successful_search ) {
				cout << "=========================================================" << endl
			         << "SUCCESS: the implicit search was conclusive.             " << endl 
				     << "There are no bifurcations occurring for these parameters." << endl
				     << "=========================================================" << endl;
			}
			else {
				cout << "========================================================= " << endl
				     << "FAILURE: the implicit search was inconclusive.            " << endl 
				     << "We will redo the computations with a bifurcation analysis." << endl
				     << "========================================================= " << endl;
		  }	
		break;
	    case 3 :  // Bifurcation analysis.
    		cout << "=========================================================" << endl
			     << "Using strategy #3: Doing a full bifurcation analysis for " << endl
			     << "the entire parameter region.                             " << endl
           		 << "=========================================================" << endl;   
      		if ( maxDiam(P) <= MIN_TOL_P ) {
				cout << "=========================================================" << endl
				     << "FAILURE: the parameter region is too narrow. Quitting.   " << endl 
				     << "=========================================================" << endl;
			  	return 0;	
			}      			
		  	// Add the three outer regions in configuration-mass-space w no bifurcations.
		  	setThreeInitialSearchDomains(workList, P);  
		  	successful_search = zoomInOnDegenerate(workList, TOL);
		  	if ( !successful_search ) {
				cout << "=========================================================" << endl
				     << "FAILURE: the outer bifurcation analysis was inconclusive." << endl 
				     << "=========================================================" << endl;
		    return 0;  
			}
			cout << "=========================================================" << endl
				 << "SUCCESS: the outer bifurcation analysis was conclusive.  " << endl 
				 << "There are no bifurcations occurring for these parameters." << endl
				 << "=========================================================" << endl;
			// Work on the remaining inner region, where bifurcations can occur.
			setOneInitialSearchDomain(workList, P); 
			successful_search = performBifurcationAnalysis(workList, MIN_TOL_P);
			if ( !successful_search ) { 
				cout << "=========================================================" << endl
					 << "FAILURE: the inner bifurcation analysis was inconclusive." << endl 
					 << "=========================================================" << endl;	
				return 0;		 				 	   
			}		  
			cout << "=========================================================" << endl
				 << "SUCCESS: the inner bifurcation analysis was conclusive.  " << endl 
		       	 << "=========================================================" << endl;
      	break;
    default :
      	cout << "Invalid: you must select a strategy in {1,2,3}." << endl;
  	}
  	curr = time(0);
  	cout << "Ended computations: " << ctime(&curr)
	     << "=========================================================" << endl;
  	return 0;
}
