/*   File: potential_functions.cc

	 All sorts of functions relating to the gravitational potential.

	 Author: Warwick Tucker
	 Email : warwick.tucker@monash.edu
	 Latest edit: Fri 04 Feb 2022 13:49:37 AEDT
*/

#include "potential_functions.h"

//----------------------------------------------------------------------
// Checks if F is well-defined on XP.
//
bool containsPrimaries(const IVector &XP)
{
	static interval pi_sixths = interval::pi() / interval(6.0);
	interval r = XP(1);
	interval a = XP(2);
	if (subset(1.0, r) && (subset(0.0, a - pi_sixths) || subset(0.0, a + pi_sixths)))
		return true;

	return false;
}

//----------------------------------------------------------------------
// Checks if XP withstands two near distance tests, one for when
// m1 is small (Theorem 16), and one for larger masses (Lemma 2).
// Returns true if we pass both tests. If we fail a test, then XP
// cannot contain a critical point, and we return false.
//
bool nearDistanceTest(const IVector &XP)
{
	static interval pi_sixths = interval::pi() / interval(6.0); // pi/6 \in 0.52359877[5,7]
	static double DELTA = 5e-1;									// Max distance to a primary for both tests.
	static double M_EPS = 1e-2;									// Max value of m1 or m2 for Theorem 16.
	static double R_EPS = 1e-3;									// Max value of distance for Theorem 16.

	interval r = XP(1);
	interval a1 = XP(2) - pi_sixths;
	interval a2 = XP(2) + pi_sixths;
	interval s = XP(3);
	interval t = XP(4);
	interval m1 = s * t;
	interval m2 = (1 - s) * t;
	interval m3 = 1 - t;

	if ((Mag(r - 1) < DELTA) && (Mag(a1) <= DELTA))
	{ // X is close to p1 (far from p2).
		interval d1;

		if (!subset(1.0, r) || !subset(0.0, a1)) // X does not contain p1.
			d1 = dist_prim(r, a1);
		else
		{ // X may/may not contain p1.
			interval D1 = dist_prim_crude(Inf(r), Inf(a1));
			interval D2 = dist_prim_crude(Inf(r), Sup(a1));
			interval D3 = dist_prim_crude(Sup(r), Inf(a1));
			interval D4 = dist_prim_crude(Sup(r), Sup(a1));
			d1 = Hull(Hull(D1, D2), Hull(D3, D4));
		}
		if (subset(0.0, d1)) // X contains p1.
			d1 = interval(Sup(d1));
		if ((Sup(m1) < M_EPS) && (Sup(d1) < R_EPS))
		{				  // If m1 is small, and we are near p1,
			return false; // then we use Theorem 16.
		}
		if (Inf(m1 / sqr(d1)) > Sup((1 - m1) / sqr(1 - d1) + d1 + 1))
		{
			return false; // Use Lemma 2 for i = 1.
		}
	}

	if ((Mag(r - 1) < DELTA) && (Mag(a2) <= DELTA))
	{ // X is close to p2 (far from p1).
		interval d2;

		if (!subset(1.0, r) || !subset(0.0, a2)) // X does not contain p2.
			d2 = dist_prim(r, a2);
		else
		{ // X may/may not contain p2.
			interval D1 = dist_prim_crude(Inf(r), Inf(a2));
			interval D2 = dist_prim_crude(Inf(r), Sup(a2));
			interval D3 = dist_prim_crude(Sup(r), Inf(a2));
			interval D4 = dist_prim_crude(Sup(r), Sup(a2));
			d2 = Hull(Hull(D1, D2), Hull(D3, D4));
		}
		if (subset(0.0, d2)) // X contains p2.
			d2 = interval(Sup(d2));
		if ((Sup(m1) < M_EPS) && (Sup(d2) < R_EPS))
		{ // m1 is small, and we are near p2.
			return false;
		}
		if (Inf(m2 / sqr(d2)) > Sup((1 - m2) / sqr(1 - d2) + d2 + 1))
		{ // Lemma 2 for i = 2.
			return false;
		}
	}

	return true;
}

//----------------------------------------------------------------------
// Checks if the distance function for primaries is safe to evaluate.
// Note that we use +- pi/6 here, since this is what is needed.
//
bool dist_prim_crude_ok(const IVector &XP)
{
	static interval pi_sixths = interval::pi() / interval(6.0);
	interval r = XP(1);
	interval a_neg = XP(2) - pi_sixths;
	interval a_pos = XP(2) + pi_sixths;
	interval arg_neg = sqr(r) - 2 * r * cos(a_neg) + 1;
	interval arg_pos = sqr(r) - 2 * r * cos(a_pos) + 1;

	if ((Inf(arg_neg) <= 0.0) || (Inf(arg_pos) <= 0.0))
		return false;
	return true;
}

//----------------------------------------------------------------------
// The distance function for primaries.
//
interval dist_prim_crude(const interval &r, const interval &a)
{
	return sqrt(sqr(r) - 2 * r * cos(a) + 1);
}

//----------------------------------------------------------------------
// The more accurate distance function for primaries. Here we check the
// four corners and the local extrema (if any)
//
interval dist_prim(const interval &r, const interval &a)
{
	interval d1 = dist_prim_crude(Inf(r), Inf(a));
	interval d2 = dist_prim_crude(Inf(r), Sup(a));
	interval d3 = dist_prim_crude(Sup(r), Inf(a));
	interval d4 = dist_prim_crude(Sup(r), Sup(a));
	interval D1 = Hull(Hull(d1, d2), Hull(d3, d4));
	interval dfdr = (r - cos(a)); // This is a sharp enclosure!
	interval dfda = r * sin(a);	  // This is a sharp enclosure!

	// Monotone in both r and a.
	if (!subset(0.0, dfdr) && !subset(0.0, dfda))
		return D1;

	// Not monotone in a, so check sin(a) = 0. With our contraints, this
	// means a = 0 or a = pi. (-pi has the same effect as +pi here).
	if (subset(0.0, dfda))
	{
		if (subset(0.0, a))
		{
			d1 = dist_prim_crude(Inf(r), 0.0);
			d2 = dist_prim_crude(Sup(r), 0.0);
			D1 = Hull(D1, Hull(d1, d2));
		}
		if (subset(0.0, a - interval::pi()) || subset(0.0, a + interval::pi()))
		{
			d3 = dist_prim_crude(Inf(r), interval::pi());
			d4 = dist_prim_crude(Sup(r), interval::pi());
			D1 = Hull(D1, Hull(d3, d4));
		}
	}

	// Not monotone in a r, so check cos(a) = r for extremal a.
	if (subset(0.0, dfdr) && !subset(0.0, dfda))
	{
		interval r1 = cos(interval(Inf(a)));
		interval r2 = cos(interval(Sup(a)));
		d1 = dist_prim_crude(r1, Inf(a));
		d2 = dist_prim_crude(r1, Sup(a));
		d3 = dist_prim_crude(r2, Inf(a));
		d4 = dist_prim_crude(r2, Sup(a));
		interval D3 = Hull(Hull(d1, d2), Hull(d3, d4));
		D1 = Hull(D1, D3);
	}

	return D1;
}

//----------------------------------------------------------------------
// A wrapper for the more accurate distance function for primaries.
//
interval dist_prim(const IVector &XP)
{
	interval r = XP(1);
	interval a = XP(2);
	return dist_prim(r, a);
}

//----------------------------------------------------------------------
// Utility functions
//
interval Z(const interval &r, const interval a)
{
	return 1 - 1.0 / power(dist_prim(r, a), 3);
}

interval dZdr(const interval &r, const interval a)
{
	return 3 * (r - cos(a)) / power(dist_prim(r, a), 5);
}

//----------------------------------------------------------------------
// A partial derivative we often need.
//
interval dWdr(const interval &r, const interval &a)
{
	return (cos(a) - r) / power(dist_prim(r, a), 3) - cos(a);
}

//----------------------------------------------------------------------
// A partial derivative (rescaled by 1/r) we often need.
//
interval dWda_over_r(const interval &r, const interval a)
{
	return sin(a) * Z(r, a);
}

//----------------------------------------------------------------------
// Various second partial derivatives (appropriately rescaled) we often need.
//
interval d2Wda2(const interval &r, const interval a)
{
	return r * cos(a) * (1 - 1.0 / power(dist_prim(r, a), 3)) + 3 * sqr(r) * sqr(sin(a)) / power(dist_prim(r, a), 5);
}

interval d2Wdr2(const interval &r, const interval a)
{
	return 3 * sqr(r - cos(a)) / power(dist_prim(r, a), 5) - 1.0 / power(dist_prim(r, a), 3);
}

interval d2Wda_over_rdr(const interval &r, const interval a)
{
	return 3 * (r - cos(a)) * sin(a) / power(dist_prim(r, a), 5);
}

interval d2Wdrda(const interval &r, const interval a)
{
	return sin(a) * (1 + 3 * (r - cos(a)) * r / power(dist_prim(r, a), 5) - 1.0 / power(dist_prim(r, a), 3));
}

interval d2Wda2_over_r(const interval &r, const interval a)
{
	return cos(a) * (1 - 1.0 / power(dist_prim(r, a), 3)) + 3 * r * sqr(sin(a)) / power(dist_prim(r, a), 5);
}

//----------------------------------------------------------------------
// The rescaled gradient of the potential.
//
IVector F(const IVector &X, const IVector &P)
{
	static interval pi_sixths = interval::pi() / interval(6.0);
	// Shorthand for polar coordinates.
	interval r = X(1);
	interval a = X(2);

	// Shorthand for mass parameters.
	interval s = P(1);
	interval t = P(2);

	IVector Y(2);
	Y(1) = r - (1 - t) / sqr(r) + s * t * dWdr(r, a - pi_sixths) + (1 - s) * t * dWdr(r, a + pi_sixths);
	Y(2) = s * dWda_over_r(r, a - pi_sixths) + (1 - s) * dWda_over_r(r, a + pi_sixths);

	return Y;
}

//----------------------------------------------------------------------
// A wrapper for the rescaled gradient.
//
IVector F(const IVector &XP)
{
	IVector X(DIM);
	IVector P(DIM);
	X(1) = XP(1);
	X(2) = XP(2);
	P(1) = XP(3);
	P(2) = XP(4);
	return F(X, P);
}

//----------------------------------------------------------------------
// The rescaled gradient of the potential with AD.
// in = (X(1),X(2)) = (r,a); param = (P(1),P(2),pi/6) = (s,t,pi_sixths).
//
void F_AD(Node n, Node in[], int dimIn, Node out[], int dimOut, Node param[], int dimP)
{
	Node r = in[0];
	Node a = in[1];

	Node s = param[0];
	Node t = param[1];
	Node pi_sixths = param[2];

	Node a_neg = a - pi_sixths;
	Node a_pos = a + pi_sixths;

	Node d_neg = sqrt(sqr(r) - 2 * r * cos(a_neg) + 1);
	Node d_pos = sqrt(sqr(r) - 2 * r * cos(a_pos) + 1);

	Node dWdr_neg = (cos(a_neg) - r) / (d_neg ^ 3) - cos(a_neg);
	Node dWdr_pos = (cos(a_pos) - r) / (d_pos ^ 3) - cos(a_pos);

	Node dWda_over_r_neg = sin(a_neg) * (1 - 1.0 / (d_neg ^ 3));
	Node dWda_over_r_pos = sin(a_pos) * (1 - 1.0 / (d_pos ^ 3));

	out[0] = r - (1 - t) / sqr(r) + s * t * dWdr_neg + (1 - s) * t * dWdr_pos;
	out[1] = s * dWda_over_r_neg + (1 - s) * dWda_over_r_pos;
}

//----------------------------------------------------------------------
// The Jacobian of the rescaled gradient of the potential.
//
IMatrix DF(const IVector &X, const IVector &P)
{
	static interval pi_sixths = interval::pi() / interval(6.0);

	// Shorthand for polar coordinates.
	interval r = X(1);
	interval a = X(2);

	// Shorthand for mass parameters.
	interval s = P(1);
	interval t = P(2);

	IMatrix DY(2, 2);
	DY(1, 1) = 1 + 2 * (1 - t) / power(r, 3) + s * t * d2Wdr2(r, a - pi_sixths) + (1 - s) * t * d2Wdr2(r, a + pi_sixths);
	DY(1, 2) = s * t * d2Wdrda(r, a - pi_sixths) + (1 - s) * t * d2Wdrda(r, a + pi_sixths);
	DY(2, 1) = s * d2Wda_over_rdr(r, a - pi_sixths) + (1 - s) * d2Wda_over_rdr(r, a + pi_sixths);
	DY(2, 2) = s * d2Wda2_over_r(r, a - pi_sixths) + (1 - s) * d2Wda2_over_r(r, a + pi_sixths);

	return DY;
}

//----------------------------------------------------------------------
// A wrapper for the Jacobian.
//
IMatrix DF(const IVector &XP)
{
	IVector X(DIM);
	IVector P(DIM);
	X(1) = XP(1);
	X(2) = XP(2);
	P(1) = XP(3);
	P(2) = XP(4);
	return DF(X, P);
}

//----------------------------------------------------------------------
// The Jacobian of the rescaled gradient of the potential with AD.
// in = (X(1),X(2)) = (r,a); param = (P(1),P(2),pi/6) = (s,t,pi_sixths).
//
void DF_AD(Node n, Node in[], int dimIn, Node out[], int dimOut, Node param[], int dimP)
{
	Node r = in[0];
	Node a = in[1];

	Node s = param[0];
	Node t = param[1];
	Node pi_sixths = param[2];

	Node a_neg = a - pi_sixths;
	Node a_pos = a + pi_sixths;

	Node d_neg = sqrt(sqr(r) - 2 * r * cos(a_neg) + 1);
	Node d_pos = sqrt(sqr(r) - 2 * r * cos(a_pos) + 1);

	Node d2Wdr2_neg = 3 * sqr(r - cos(a_neg)) / (d_neg ^ 5) - 1.0 / (d_neg ^ 3);
	Node d2Wdr2_pos = 3 * sqr(r - cos(a_pos)) / (d_pos ^ 5) - 1.0 / (d_pos ^ 3);
	Node d2Wdrda_neg = sin(a_neg) * (1 + 3 * (r - cos(a_neg)) * r / (d_neg ^ 5) - 1.0 / (d_neg ^ 3));
	Node d2Wdrda_pos = sin(a_pos) * (1 + 3 * (r - cos(a_pos)) * r / (d_pos ^ 5) - 1.0 / (d_pos ^ 3));
	Node d2Wda_over_rdr_neg = 3 * (r - cos(a_neg)) * sin(a_neg) / (d_neg ^ 5);
	Node d2Wda_over_rdr_pos = 3 * (r - cos(a_pos)) * sin(a_pos) / (d_pos ^ 5);
	Node d2Wda2_over_r_neg = cos(a_neg) * (1 - 1.0 / (d_neg ^ 3)) + 3 * r * sqr(sin(a_neg)) / (d_neg ^ 5);
	Node d2Wda2_over_r_pos = cos(a_pos) * (1 - 1.0 / (d_pos ^ 3)) + 3 * r * sqr(sin(a_pos)) / (d_pos ^ 5);

	// NOTE: strange ordering wrt indexing. Enforced by IMap.
	// df1/dr
	out[0] = 1 + 2 * (1 - t) / (r ^ 3) + s * t * d2Wdr2_neg + (1 - s) * t * d2Wdr2_pos;
	// df2/dr
	out[1] = s * d2Wda_over_rdr_neg + (1 - s) * d2Wda_over_rdr_pos;
	// df1/da
	out[2] = s * t * d2Wdrda_neg + (1 - s) * t * d2Wdrda_pos;
	// df2/da
	out[3] = s * d2Wda2_over_r_neg + (1 - s) * d2Wda2_over_r_pos;
}

//----------------------------------------------------------------------
// Yet another wrapper for the Jacobian af the rescaled AD-gradient.
//
IMatrix DF(const IVector &XP, IMap &adDF, IMatrix &HF)
{
	IVector X(DIM);
	IVector P(DIM);
	X(1) = XP(1);
	X(2) = XP(2);
	P(1) = XP(3);
	P(2) = XP(4);
	adDF.setParameter(0, P(1));
	adDF.setParameter(1, P(2));
	IVector DFX_v = adDF(X, HF);
	IMatrix DFX(DIM, DIM);
	DFX(1, 1) = DFX_v(1);
	DFX(1, 2) = DFX_v(3);
	DFX(2, 1) = DFX_v(2);
	DFX(2, 2) = DFX_v(4);
	return DFX;
}

//----------------------------------------------------------------------
// Yet another wrapper for the Jacobian af the rescaled AD-gradient.
//
IMatrix DF(const IVector &XP, IMap &adDF, IMatrix &HF, IHessian &HF3)
{
	IVector X(DIM);
	IVector P(DIM);
	X(1) = XP(1);
	X(2) = XP(2);
	P(1) = XP(3);
	P(2) = XP(4);
	adDF.setParameter(0, P(1));
	adDF.setParameter(1, P(2));
	IVector DFX_v = adDF(X, HF, HF3);
	IMatrix DFX(DIM, DIM);
	DFX(1, 1) = DFX_v(1);
	DFX(1, 2) = DFX_v(3);
	DFX(2, 1) = DFX_v(2);
	DFX(2, 2) = DFX_v(4);
	return DFX;
}

//----------------------------------------------------------------------
// A recursive, deep trial for F(XP) != 0.
//
bool nonZeroD0F(const IVector &XP, double TOL)
{
	RVector wX(4);
	wX(1) = 1.0;
	wX(2) = 1.0;
	wX(3) = 0.0;
	wX(4) = 0.0;
	List<IVector> workList;
	workList += XP;
	while (!IsEmpty(workList))
	{
		IVector XP = Pop(workList);
		IVector X(2);
		X(1) = XP(1);
		X(2) = XP(2);
		if (subset(0.0, F(XP)))
		{
			if (maxDiam(X) < TOL)
				return false;
			else
				splitAndStore(XP, workList, wX);
		}
	}
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for det(DF(XP)) != 0.
//
bool nonZeroDetDF(const IVector &XP, double TOL)
{
	RVector wX(4);
	wX(1) = 1.0;
	wX(2) = 1.0;
	wX(3) = 0.0;
	wX(4) = 0.0;
	List<IVector> workList;
	workList += XP;
	while (!IsEmpty(workList))
	{
		IVector XP_loc = Pop(workList);
		IVector X(2);
		X(1) = XP_loc(1);
		X(2) = XP_loc(2);
		if (subset(0.0, det2x2(DF(XP_loc))))
		{
			if (maxDiam(X) < TOL)
				return false;
			else
				splitAndStore(XP_loc, workList, wX);
		}
	}
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for det(DF(XP)) != 0 over xpList.
//
bool nonZeroDetDF(List<IVector> &xpList, double TOL)
{
	First(xpList);
	while (!Finished(xpList))
	{
		IVector XP = Current(xpList);
		if (!nonZeroDetDF(XP, TOL))
			return false;
		Next(xpList);
	}
	return true;
}

//----------------------------------------------------------------------
// Returns the upper bound of all elements of ivList.
//
double upperBound(List<interval> &ivList)
{
	double result = Sup(First(ivList));
	while (!Finished(ivList))
	{
		double ub = Sup(Current(ivList));
		if (result < ub)
			result = ub;
		Next(ivList);
	}
	return result;
}

//----------------------------------------------------------------------
// Returns the lower bound of all elements of ivList.
//
double lowerBound(List<interval> &ivList)
{
	double result = Inf(First(ivList));
	while (!Finished(ivList))
	{
		double lb = Inf(Current(ivList));
		if (result > lb)
			result = lb;
		Next(ivList);
	}
	return result;
}

//----------------------------------------------------------------------
// Fills the output lists with enclosures of the zeros of Fi. We are
// assuming (kind of) that one of the two first components of XP is
// thin. The splitting (and the search) occurs in the other component.
//
void coverAllZerosFi(List<interval> &zeroListFi, int i,
					 const IVector &XP_search, double TOL)
{
	int splitComponent(0);
	if (diameter(XP_search(1)) < diameter(XP_search(2)))
		splitComponent = 2; // We split in the second component.
	else
		splitComponent = 1; // We split in the first component.

	RVector wX(4);
	wX(1) = 0.0;
	wX(2) = 0.0;
	wX(3) = 0.0;
	wX(4) = 0.0;
	wX(splitComponent) = 1.0;

	List<IVector> workList;

	// Enclose the zeros of Fi.
	workList += XP_search;
	while (!IsEmpty(workList))
	{
		IVector XP_loc = Pop(workList);
		if (subset(0.0, F(XP_loc)(i)))
		{
			if (diameter(XP_loc(splitComponent)) < TOL)
				zeroListFi += XP_loc(splitComponent);
			else
				splitAndStore(XP_loc, workList, wX);
		}
	}
}

//----------------------------------------------------------------------
// Fills the output lists with enclosures of the zeros of F1 and F2.
//
void coverAllZeros(List<interval> &zeroListF1, List<interval> &zeroListF2,
				   const IVector &XP_search, double TOL)
{
	coverAllZerosFi(zeroListF1, 1, XP_search, TOL);
	coverAllZerosFi(zeroListF2, 2, XP_search, TOL);
}

//----------------------------------------------------------------------
// Checks if the level-set f_2 = 0 crosses the boundary of X exactly
// twice. If so we return the value "true"; otherwise "false". We are
// assuming that df_2/dx_2 is positive in XP. Note that when we see
// 1 or 3 "intersections" we know that one of them is not really there,
// it means 0 or 2 true boundary crossings by a topological argument.
// This means that the set f_2 = 0 forms at most one connected component
// in the box X, which allows us the use the L-S reduction properly.
//
bool exactly_two_intersections(const IVector &XP)
{
	int intersections(0); // Found intersections.
	IVector XP_s(XP), XP_w(XP), XP_n(XP), XP_e(XP);
	XP_s(2) = Inf(XP(2)); // South boundary.
	XP_w(1) = Inf(XP(1)); // West boundary.
	XP_n(2) = Sup(XP(2)); // North boundary.
	XP_e(2) = Sup(XP(1)); // East boundary.
	double TOL_x = diameter(XP(1)) / 50.0;
	double TOL_y = diameter(XP(2)) / 50.0;

	IVector XP_sw(XP);
	XP_sw(1) = Inf(XP(1));
	XP_sw(2) = Inf(XP(2));
	IVector XP_ne(XP);
	XP_ne(1) = Sup(XP(1));
	XP_ne(2) = Sup(XP(2));
	IVector FXP_sw = F(XP_sw);
	IVector FXP_ne = F(XP_ne);
	if ((Sup(FXP_sw(2)) >= 0) || (Inf(FXP_ne(2)) <= 0.0))
	{
		return false;
	}

	// From here on we know that F_2 is negative at the SW corner,
	// and positive at the NE corner. This implies that F_2 must
	// change sign along the west+north boundary segment, as well
	// as along the east+south boundary segment.

	// Checking south boundary.
	List<interval> zeroListF2_s;
	coverAllZerosFi(zeroListF2_s, 2, XP_s, TOL_x);
	if (Length(zeroListF2_s) > 0)
	{
		double x_lo = lowerBound(zeroListF2_s);
		double x_hi = upperBound(zeroListF2_s);
		interval zero_x(x_lo, x_hi);
		IVector XP_s_zero(XP_s);
		XP_s_zero(1) = zero_x;
		interval Df21 = DF(XP_s_zero)(2, 1);
		if (0.0 < Inf(Df21)) // At most one true intersection since
			intersections++; // df2/dx1 is positive.
		else
			return false; // We cannot account for all intersections.
	}
	else
	{
		// cout << "No zeros along XP_s" << endl;
	}
	// Checking west boundary.
	List<interval> zeroListF2_w;
	coverAllZerosFi(zeroListF2_w, 2, XP_w, TOL_y);
	if (Length(zeroListF2_w) != 0)
	{
		double y_lo = lowerBound(zeroListF2_w);
		double y_hi = upperBound(zeroListF2_w);
		interval zero_y(y_lo, y_hi);
		intersections++; // We use the fact that df2/dx2 is positive in XP.
	}
	else
	{
		// cout << "No zeros along XP_w" << endl;
	}
	// Checking north boundary.
	List<interval> zeroListF2_n;
	coverAllZerosFi(zeroListF2_n, 2, XP_n, TOL_x);
	if (Length(zeroListF2_n) > 0)
	{
		double x_lo = lowerBound(zeroListF2_n);
		double x_hi = upperBound(zeroListF2_n);
		interval zero_x(x_lo, x_hi);
		IVector XP_n_zero(XP_n);
		XP_n_zero(1) = zero_x;
		interval Df21 = DF(XP_n_zero)(2, 1);
		if (0.0 < Df21)		 // At most one intersection since
			intersections++; // df2/dx1 is positive.
		else
			return false; // We cannot account for all intersections.
	}
	else
	{
		// cout << "No zeros along XP_n" << endl;
	}
	// Checking east boundary.
	List<interval> zeroListF2_e;
	coverAllZerosFi(zeroListF2_e, 2, XP_e, TOL_y);
	if (Length(zeroListF2_e) > 0)
	{
		double y_lo = lowerBound(zeroListF2_e);
		double y_hi = upperBound(zeroListF2_e);
		interval zero_y(y_lo, y_hi);
		intersections++; // We use the fact that df2/dx2 is positive in XP.
	}
	else
	{
		// cout << "No zeros along XP_e" << endl;
	}
	// We have now traversed the four boundary segments of X.
	if (intersections == 4)
	{
		cout << "exactly_two_intersections: failed."
			 << " intersections = " << intersections << endl
			 << endl;
		return false;
	}
	// cout << "exactly_two_intersections: success." << endl << endl;
	return true; // Perfect; f2 = 0 has exactly one connected component in X.
}

//----------------------------------------------------------------------
// Checks if D2G is well-defined; if so it returns the interval image.
// We always verify that df_2/dx_2 is positive first.
//
bool D2G_well_defined(interval &D2G_XP, const IVector &XP, IMap &adF, IMap &adDF)
{
	if (!dist_prim_crude_ok(XP))
		return false;

	IMatrix Df(2, 2);
	IMatrix Hf(4, 2);
	Df = DF(XP, adDF, Hf); // 1st and 2nd derivatives of f.

	if (!(0.0 < Inf(Df(2, 2))))
		return false;

	// We have found a good direction for L-S reduction.
	int i(1), j(1);
	interval xjPrime = -Df[i][1 - j] / Df[i][j];
	interval xjSecond = -(Hf[i + 2 * j][j] * sqr(xjPrime) + (Hf[i + 2 * j][1 - j] + Hf[i + 2 * (1 - j)][j]) * xjPrime + Hf[i + 2 * (1 - j)][1 - j]) / Df[i][j];
	interval gSecond = Hf[1 - i + 2 * j][j] * power(xjPrime, 2) + (Hf[1 - i + 2 * j][1 - j] + Hf[1 - i + 2 * (1 - j)][j]) * xjPrime + Hf[1 - i + 2 * (1 - j)][1 - j] + Df[1 - i][j] * xjSecond;
	D2G_XP = gSecond;
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for g''(XP) != 0.
//
bool nonZeroD2G(const IVector &XP, double TOL, IMap &adF, IMap &adDF)
{
	// Here we hard code some bound guiding our guess as to where we
	// can find the quadratic bifurcations. Only heuristic of course!
	double k = 1.2 / 27;
	double m = 0.55178;
	double y = Inf(XP(4));
	double x = Sup(XP(3));

	if ((0.58 <= Sup(XP(4))) || (y < k * x + m))
		return false;

	if (x < 0.223)
		return false;

	RVector wX(4);
	wX(1) = 1.0;
	wX(2) = 1.0;
	wX(3) = 0.0;
	wX(4) = 0.0;
	List<IVector> workList;
	workList += XP;
	while (!IsEmpty(workList))
	{
		IVector XP_loc = Pop(workList);
		IVector X(2);
		X(1) = XP_loc(1);
		X(2) = XP_loc(2);
		interval D2G_XP;
		if (!D2G_well_defined(D2G_XP, XP_loc, adF, adDF) || subset(0.0, D2G_XP))
		{
			if (maxDiam(X) < TOL)
				return false;
			else
				splitAndStore(XP_loc, workList, wX);
		}
	}
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for g''(XP) != 0 over xpList.
//
bool nonZeroD2G(List<IVector> &xpList, double TOL, IMap &adF, IMap &adDF)
{
	First(xpList);
	while (!Finished(xpList))
	{
		IVector XP = Current(xpList);
		if (!nonZeroD2G(XP, TOL, adF, adDF))
			return false;
		Next(xpList);
	}
	return true;
}

//----------------------------------------------------------------------
// Checks if D3G is well-defined; if so it returns the interval image.
// We always verify that df_2/dx_2 is positive.
//
bool D3G_well_defined(interval &D3G_XP, const IVector &XP, IMap &adF, IMap &adDF)
{
	// Added by WT 220210
	interval s = XP(3);
	if (Inf(s) > 0.223)
		return false;

	if (!dist_prim_crude_ok(XP))
		return false;

	IMatrix Df(2, 2);
	IMatrix Hf(4, 2);
	IHessian Hf3(4, 2);
	Df = DF(XP, adDF, Hf, Hf3); // 1st, 2nd, 3rd derivatives of f.

	if (!(0.0 < Inf(Df(2, 2)))) // Check for potential trouble.
		return false;

	// We have found a good direction for L-S reduction. From here on,
	// we know that Df_2/dx_2 is positive in X.

	int i(1), j(1); // Switching to array indexing for the AD.

	interval xjPrime = -Df[i][1 - j] / Df[i][j];
	interval xjSecond = -(Hf[i + 2 * j][j] * sqr(xjPrime) + (Hf[i + 2 * j][1 - j] + Hf[i + 2 * (1 - j)][j]) * xjPrime + Hf[i + 2 * (1 - j)][1 - j]) / Df[i][j];

	interval gSecond = Hf[1 - i + 2 * j][j] * power(xjPrime, 2) + (Hf[1 - i + 2 * j][1 - j] + Hf[1 - i + 2 * (1 - j)][j]) * xjPrime + Hf[1 - i + 2 * (1 - j)][1 - j] + Df[1 - i][j] * xjSecond;

	interval xThird = -(Hf3(i + 2 * j, j, j) * power(xjPrime, 3) + 3. * Hf3(i + 2 * j, j, 1 - j) * power(xjPrime, 2) + 3. * Hf3(i + 2 * j, 1 - j, 1 - j) * xjPrime + Hf3(i + 2 * (1 - j), 1 - j, 1 - j) + 3. * Hf[i + 2 * j][j] * xjPrime * xjSecond + 3. * Hf[i + 2 * j][1 - j] * xjSecond) / Df[i][j];

	interval gThird = Hf3(1 - i + 2 * j, j, j) * power(xjPrime, 3) + 3. * Hf3(1 - i + 2 * j, j, 1 - j) * power(xjPrime, 2) + 3. * Hf3(1 - i + 2 * j, 1 - j, 1 - j) * xjPrime + Hf3(1 - i + 2 * (1 - j), 1 - j, 1 - j) + 3. * Hf[1 - i + 2 * j][j] * xjPrime * xjSecond + 3. * Hf[1 - i + 2 * j][1 - j] * xjSecond + Df[1 - i][j] * xThird;

	D3G_XP = gThird;
	return true;
}

//----------------------------------------------------------------------
// Check if there is at least one zero of F inside the connected component
// xpList.X for all p in xpList.P. Returns false unless confirmed true.
// We use the fact that all solutions inside the reqion C0 are contained
// in the single connected component xpList.X. Therefore we can use a fixed
// (larger) box than Hull(xpList.X), which gives us fewer cases to check.
// If successful, we can apply the Poincare'-Miranda Theorem.
//
bool atLeastOneSol(List<IVector> &xpList)
{
	IVector XP = First(xpList);
	XP(1) = interval(6, 9) / 10.0; // The r range: [0.6, 0.9] \subset [0.33, 1.0].
	XP(2) = interval(1, 4) / 10.0; // The a range: [0.1, 0.4] \subset [-0.2, 0.7].

	// Check that all x in xplist belong to the X of XP. This is where
	// all "at most three solutions"-type bifurcations happen.
	while (!Finished(xpList))
	{
		IVector XP_loc = Current(xpList);
		if (!XP_loc(1).subset(XP(1)) || !XP_loc(2).subset(XP(2)))
		{
			cerr << "atLeastOneSol: xList is not a subset of the X of XP." << endl;
			return false;
		}
		Next(xpList);
	}

	// OK, good. Now we know that the (r,a)-region is large enough.
	// Now we must prove that there is at least one solution inside.

	// First, verify that both F_i are negative at Inf(X1)*Inf(X2).
	IVector XP_sw = XP;
	XP_sw(1) = Inf(XP(1));
	XP_sw(2) = Inf(XP(2));
	IVector F_sw = F(XP_sw);
	if ((Sup(F_sw(1)) < 0.0) && (Sup(F_sw(2)) < 0.0))
	{
		//	cout << "Both F_i are negative at Inf(X1)*Inf(X2)." << endl;
	}
	else
	{
		cerr << "Cannot prove that F is negative at Inf(X1)*Inf(X2)." << endl;
		return false;
	}

	// Next, we verify that both F_i are positive at Sup(X1)*Sup(X2).
	IVector XP_ne = XP;
	XP_ne(1) = Sup(XP(1));
	XP_ne(2) = Sup(XP(2));
	IVector F_ne = F(XP_ne);
	if ((Inf(F_ne(1)) > 0.0) && (Inf(F_ne(2)) > 0.0))
	{
		//	cout << "Both F_i are positive at Sup(X1)*Sup(X2)" << endl;
	}
	else
	{
		cerr << "Cannot prove that F is positive at Sup(X1)*Sup(X2)." << endl;
		return false;
	}

	// Set some (arbitrary) splitting tolerances.
	double TOL_x = diameter(XP(1)) / 50.0;
	double TOL_y = diameter(XP(2)) / 50.0;

	// Next, check that no F_i vanishes on Inf(X1)*X2; the west side.
	IVector XP_w = XP;
	XP_w(1) = Inf(XP(1));
	List<interval> zeroListF1_w, zeroListF2_w;
	coverAllZeros(zeroListF1_w, zeroListF2_w, XP_w, TOL_y);
	// Verify that there are no zeros along the west side.
	if ((Length(zeroListF1_w) > 0) || (Length(zeroListF2_w) > 0))
	{
		cerr << "|zeroListF1_w| = " << Length(zeroListF1_w) << " "
			 << "|zeroListF2_w| = " << Length(zeroListF2_w) << endl;
		return false;
	}

	// Next, check that no F_i vanishes on X1*Inf(X2); the south side.
	IVector XP_s = XP;
	XP_s(2) = Inf(XP(2));
	List<interval> zeroListF1_s, zeroListF2_s;
	coverAllZeros(zeroListF1_s, zeroListF2_s, XP_s, TOL_x);
	// Verify that there are no zeros along the south side.
	if ((Length(zeroListF1_s) > 0) || (Length(zeroListF2_s) > 0))
	{
		cerr << "|zeroListF1_s| = " << Length(zeroListF1_s) << " "
			 << "|zeroListF2_s| = " << Length(zeroListF2_s) << endl;
		return false;
	}

	// OK, if we made it to here, then we have to verify that F1 and F2
	// change signs in the right order along the north and east sides.

	// We begin with the north side of X.
	List<interval> zeroListF1_n, zeroListF2_n;
	IVector XP_n = XP;
	XP_n(2) = Sup(XP(2));
	coverAllZeros(zeroListF1_n, zeroListF2_n, XP_n, TOL_x);
	// cout << "|zeroListF1_n| = " << Length(zeroListF1_n) << endl;
	// cout << "|zeroListF2_n| = " << Length(zeroListF2_n) << endl;
	if (upperBound(zeroListF1_n) < lowerBound(zeroListF2_n))
	{
		//	cout << "F1/F2 zeros in correct order on X1*Sup(X2)." << endl;
	}
	else
	{
		cerr << "Error for F1/F2 zeros on X1*Sup(X2)." << endl;
		return false;
	}

	// We end with the east side of X.
	List<interval> zeroListF1_e, zeroListF2_e;
	IVector XP_e = XP;
	XP_e(1) = Sup(XP(1));
	coverAllZeros(zeroListF1_e, zeroListF2_e, XP_e, TOL_y);
	// cout << "|zeroListF1_e| = " << Length(zeroListF1_e) << endl;
	// cout << "|zeroListF2_e| = " << Length(zeroListF2_e) << endl;
	if (upperBound(zeroListF2_e) < lowerBound(zeroListF1_e))
	{
		//	cout << "F1/F2 zeros in correct order on Sup(X1)*X2." << endl;
	}
	else
	{
		cerr << "Error for F1/F2 zeros on X1*Sup(X2)." << endl;
		return false;
	}

	// If we made it to here, all is good; return true.
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for g'''(XP) != 0.
//
bool nonZeroD3G(const IVector &XP, double TOL, IMap &adF, IMap &adDF)
{
	double y = Inf(XP(4));
	if (y < 0.555)
		return false;

	RVector wX(4);
	wX(1) = 1.0;
	wX(2) = 1.0;
	wX(3) = 0.0;
	wX(4) = 0.0;
	List<IVector> workList;
	workList += XP;
	while (!IsEmpty(workList))
	{
		IVector XP_loc = Pop(workList);
		interval D3G_XP;
		if (!D3G_well_defined(D3G_XP, XP_loc, adF, adDF) || subset(0.0, D3G_XP))
		{
			IVector X(2);
			X(1) = XP_loc(1);
			X(2) = XP_loc(2);
			if (maxDiam(X) < TOL)
				return false;
			else
				splitAndStore(XP_loc, workList, wX);
		}
	}
	return true;
}

//----------------------------------------------------------------------
// A recursive, deep trial for g'''(XP) != 0 over xpList.
//
bool nonZeroD3G(List<IVector> &xpList, double TOL, IMap &adF, IMap &adDF)
{
	First(xpList);
	while (!Finished(xpList))
	{
		IVector XP = Current(xpList);
		if (!nonZeroD3G(XP, TOL, adF, adDF))
			return false;
		Next(xpList);
	}
	return true;
}

//----------------------------------------------------------------------
// End of file.
//----------------------------------------------------------------------