/*   File: utlilities.cc

     Various extra utility functions used in the main code.

     Author: Warwick Tucker
     Email : warwick.tucker@monash.edu
     Latest edit: Tue Mar 9 12:52:53 CET 2022
*/

#include "utilities.h"

//----------------------------------------------------------------------
// Returns the hull of two boxes
IVector Hull(const IVector &X, const IVector &Y)
{
  int dim = X.dimension();
  if (dim != Y.dimension())
  {
    cerr << "Hull: dimensions differ. Quitting!" << endl;
    exit(0);
  }
  IVector Z = X;
  for (int i = 1; i <= dim; i++)
    Z(i) = Hull(Z(i), Y(i));
  return Z;
}

//----------------------------------------------------------------------
// Returns the hull of a list of boxes
IVector Hull(List<IVector> &xp_list)
{
  IVector XP_hull = First(xp_list);
  while (!Finished(xp_list))
  {
    IVector X = Current(xp_list);
    XP_hull = Hull(XP_hull, X);
    Next(xp_list);
  }
  return XP_hull;
}

//----------------------------------------------------------------------
// Returns the label of the special dominant coordinate component.
// We rescale a lot when masses are close to zero.
int specialDominantDirection(const IVector &X)
{
  int dim = X.dimension();

  if (dim == 1)
    return 1;

  RVector diam_x = diameter(X);
  double diam = diam_x(1);
  int iDom = 1;
  for (int i = 2; i <= dim; i++)
  {
    double idiam = diam_x(i);
    if (i == 3)
    {                           // For the s coordinate...
      idiam /= sqrt(Mid(X(i))); // ...rescale near zero m1.
    }

    if (diam < idiam)
    {
      diam = idiam;
      iDom = i;
    }
  }
  return iDom;
}
//----------------------------------------------------------------------
// Returns the label of the weighted dominant coordinate component.
//
int dominantDirection(const IVector &X, const RVector &w)
{
  int dim = X.dimension();
  RVector diam_x = diameter(X);
  double diam = w(1) * diam_x(1);
  int iDom = 1;
  for (int i = 2; i <= dim; i++)
  {
    double idiam = w(i) * diam_x(i);
    if (diam < idiam)
    {
      diam = idiam;
      iDom = i;
    }
  }
  return iDom;
}

//----------------------------------------------------------------------
// Bisects the special dominant coordinate component, and stores both halves.
//
void splitAndStore(const IVector &X, List<IVector> &domainList)
{
  IVector loX = X;
  IVector hiX = X;
  int i = specialDominantDirection(X);

  loX(i) = interval(Inf(X(i)), Mid(X(i)));
  hiX(i) = interval(Mid(X(i)), Sup(X(i)));

  domainList += loX;
  domainList += hiX;
}

//----------------------------------------------------------------------
// Bisects the weighted dominant coordinate component, and stores both halves.
//
void splitAndStore(const IVector &X, List<IVector> &domainList, const RVector &w)
{
  IVector loX = X;
  IVector hiX = X;
  int i = dominantDirection(X, w);

  loX(i) = interval(Inf(X(i)), Mid(X(i)));
  hiX(i) = interval(Mid(X(i)), Sup(X(i)));

  domainList += loX;
  domainList += hiX;
}

//----------------------------------------------------------------------
// Prints (and preserves) a list of boxes.
//
void printMyList(List<IVector> &printList, const std::string &txtFileName)
{
  ofstream txtFile(txtFileName.c_str(), ios_base::out);
  if (!txtFile)
  {
    cout << "Cannot open file: '" << txtFileName << "' for writing" << endl;
    exit(1);
  }

  if (IsEmpty(printList))
  {
    cout << "No data to write to '" << txtFileName << "'." << endl;
    return;
  }

  cout << "Writing the list to '" << txtFileName
       << "'. (" << Length(printList) << " units)." << endl;
  int dim = First(printList).dimension();
  while (!Finished(printList))
  {
    IVector X = Current(printList);
    for (int i = 1; i <= dim; i++)
      txtFile << Inf(X(i)) << " " << Sup(X(i)) << " ";
    txtFile << endl;
    Next(printList);
  }
}
//----------------------------------------------------------------------
// End of file.
//----------------------------------------------------------------------
