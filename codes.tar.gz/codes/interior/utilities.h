/*   File: utilities.h

     The header file for a basic utility functions.

     Author: Warwick Tucker <warwick@math.uu.se>
     Latest edit: Mon Apr 6 13:35:52 CET 2020
*/

#ifndef __UTILITIES_H__
#define __UTILITIES_H__

#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#include "capd/capdlib.h"
#include "interval_extras.h"
#include "list.h"

using namespace capd;
using namespace std;

typedef capd::vectalg::Vector<double, 0>   RVector;    //  vector
typedef capd::vectalg::Matrix<double, 0,0> RMatrix;    //  matrix

IVector Hull(const IVector &X, const IVector &Y);
IVector Hull(List<IVector> &xp_list);
void splitAndStore(const IVector &X, List<IVector> &domainList, const RVector &w);
void splitAndStore(const IVector &X, List<IVector> &domainList);
void printMyList (List<IVector> &printList, const std::string &txtFileName);

#endif // __UTILITIES_H__
