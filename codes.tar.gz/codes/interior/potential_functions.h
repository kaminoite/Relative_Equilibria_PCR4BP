/*   File: potential_functions.h

     The header file for all sorts of functions relating to the 
     gravitational potential.

     Author: Warwick Tucker <warwick@math.uu.se>
     Latest edit: Mon Apr 6 13:35:52 CET 2020
*/

#ifndef __POTENTIAL_FUNCTIONS_H__
#define __POTENTIAL_FUNCTIONS_H__

#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#include "capd/capdlib.h"
#include "interval_extras.h"
#include "utilities.h"
#include "list.h"

using namespace capd;
using namespace std;
using capd::autodiff::Node;

typedef capd::vectalg::Vector<double, 0>   RVector;    //  vector
typedef capd::vectalg::Matrix<double, 0,0> RMatrix;    //  matrix

#define interval Interval

const int DIM(2);

bool containsPrimaries(const IVector &XP);
bool nearDistanceTest(const IVector &XP);
bool dist_prim_crude_ok(const IVector &XP);
interval dist_prim_crude(const interval &r, const interval &a);
interval dist_prim(const interval &r, const interval &a);
interval dist_prim(const IVector &XP);
IVector F(const IVector &X, const IVector &P);
IVector F(const IVector &XP);
bool confirmedZero(const IVector &XP);
bool confirmedZero(List<IVector> &xpList);
bool atLeastOneSol(List<IVector> &xpList);
bool atLeastOneSol(const IVector &XP);
bool exactly_two_intersections(const IVector &XP);
void F_AD(Node n, Node in[], int dimIn, Node out[], int dimOut, Node param[], int dimP);
IMatrix DF(const IVector &X, const IVector &P);
IMatrix DF(const IVector &XP);
void DF_AD(Node n, Node in[], int dimIn, Node out[], int dimOut, Node param[], int dimP);
IMatrix DF(const IVector &XP, IMap &adDF, IMatrix &HF);
IMatrix DF(const IVector &XP, IMap &adDF, IMatrix &HF, IHessian &HF3);
bool nonZeroD0F(const IVector &XP, double TOL);
bool nonZeroDetDF(const IVector &XP, double TOL);
bool nonZeroDetDF(List<IVector> &xpList, double TOL);
bool D2G_well_defined(interval &D2F_XP, const IVector &XP, IMap &adF, IMap &adDF);
bool nonZeroD2G(const IVector &XP, double TOL, IMap &adF, IMap &adDF);
bool nonZeroD2G(List<IVector> &xpList, double TOL, IMap &adF, IMap &adDF);
bool D3G_well_defined(interval &D3F_XP, const IVector &XP, IMap &adF, IMap &adDF);
bool nonZeroD3G(const IVector &XP, double TOL, IMap &adF, IMap &adDF);
bool nonZeroD3G(List<IVector> &xpList, double TOL, IMap &adF, IMap &adDF);

#endif // __POTENTIAL_FUNCTIONS_H__