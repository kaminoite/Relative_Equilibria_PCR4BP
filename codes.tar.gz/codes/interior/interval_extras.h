/*   File: interval_extras.h

     The header file for a basic interval utility functions.

     Author: Warwick Tucker <warwick@math.uu.se>
     Latest edit: Mon Apr 6 13:35:52 CET 2020
*/

#ifndef __INTERVAL_EXTRAS_H__
#define __INTERVAL_EXTRAS_H__

#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#include "capd/capdlib.h"

using namespace capd;
using namespace std;

typedef capd::vectalg::Vector<double, 0>   RVector;    //  vector
typedef capd::vectalg::Matrix<double, 0,0> RMatrix;    //  matrix

bool     subset(const double &z, const IVector &Y);
bool     subset(const double &z, const interval &Y);
double   diameter(const interval &x);
RVector  diameter(const IVector &v);
RMatrix  diameter(const IMatrix &M);
double   maxDiam(const IVector &X);
interval iv_abs(const interval &X);
double   Inf(const interval &x);
double   Sup(const interval &x);
double   Mid(const interval &x);
double   Mag(const interval &x);
interval Hull(const interval &a, const interval &b);
interval det2x2(const IMatrix &M);
bool     inverse2x2(IMatrix &invM, const IMatrix &M);
bool     emptyIntersection(const interval &x, const interval &y);
bool     Intersection(IVector &Z, const IVector &X,const IVector &Y);

#endif // __INTERVAL_EXTRAS_H__
