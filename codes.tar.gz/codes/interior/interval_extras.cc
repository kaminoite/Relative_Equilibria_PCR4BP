/*   File: interval_extras.cc

	 Various extra utility functions and convenient wrappers for
	 interval analysis used in the main code.

	 Author: Warwick Tucker
	 Email : warwick.tucker@monash.edu
	 Latest edit: Wed Apr 6 12:52:53 CET 2020
*/

#include "interval_extras.h"

//----------------------------------------------------------------------
// False unless z belongs to each component of Y.
//
bool subset(const double &z, const IVector &Y)
{
	int y_size = Y.dimension();
	for (int i = 1; i <= y_size; ++i)
	{
		if (!Y(i).contains(z))
			return false;
	}
	return true;
}

//----------------------------------------------------------------------
//
bool subset(const double &z, const interval &Y)
{
	return Y.contains(z);
}

// ---------------------------------------------------------------------
//
double diameter(const interval &x)
{
	return rightBound(diam(x));
}

// ---------------------------------------------------------------------
//
RVector diameter(const IVector &v)
{
	int v_size = v.dimension();
	RVector w(v_size);
	for (int i = 1; i <= v_size; ++i)
		w(i) = rightBound(diam(v(i)));
	return w;
}

// ---------------------------------------------------------------------
//
RMatrix diameter(const IMatrix &M)
{
	RMatrix N(M.numberOfRows(), M.numberOfColumns());
	int M_rows = M.numberOfRows();
	int M_cols = M.numberOfColumns();
	for (int i = 1; i <= M_rows; ++i)
	{
		for (int j = 1; j <= M_cols; ++j)
			N(i, j) = rightBound(diam(M(i, j)));
	}
	return N;
}

//----------------------------------------------------------------------
// Returns the width of the widest component of X.
//
double maxDiam(const IVector &X)
{
	int X_size = X.dimension();
	RVector X_diam = diameter(X);
	double w = X_diam(1);
	for (int i = 2; i <= X_size; ++i)
	{
		if (w < X_diam(i))
			w = X_diam(i);
	}
	return w;
}

//----------------------------------------------------------------------
// Returns the interval absolute value of X.
//
interval iv_abs(const interval &X)
{
	return X.abs();
}

//----------------------------------------------------------------------
// Help functions.
//
double Inf(const interval &x)
{
	return x.leftBound();
}

double Sup(const interval &x)
{
	return x.rightBound();
}

double Mid(const interval &x)
{
	return x.mid().rightBound();
}

double Mag(const interval &x)
{
	return Sup(iv_abs(x));
}

interval Hull(const interval &a, const interval &b)
{
	return intervalHull(a, b);
}

//----------------------------------------------------------------------
// Computes the determinant of a 2x2 matrix.
//
interval det2x2(const IMatrix &M)
{
	return M(1, 1) * M(2, 2) - M(1, 2) * M(2, 1);
}

//----------------------------------------------------------------------
// Explicit matrix inverter for 2x2 systems.
//
bool inverse2x2(IMatrix &invM, const IMatrix &M)
{
	interval D = det2x2(M);
	if (subset(0.0, D))
		return false;
	invM(1, 1) = M(2, 2);
	invM(1, 2) = -M(1, 2);
	invM(2, 1) = -M(2, 1);
	invM(2, 2) = M(1, 1);
	invM = invM / D;
	return true;
}

// ---------------------------------------------------------------------
// Help functions.
//
bool emptyIntersection(const interval &x, const interval &y)
{
	return ((x.rightBound() < y.leftBound()) || (y.rightBound() < x.leftBound()));
}

bool Intersection(IVector &Z, const IVector &X, const IVector &Y)
{
	int dim = X.dimension();
	for (int i = 1; i <= dim; ++i)
	{
		if (emptyIntersection(X(i), Y(i)))
			return false;
	}
	// All components have non-empty intersection.
	Z = intersection(X, Y);
	return true;
}
