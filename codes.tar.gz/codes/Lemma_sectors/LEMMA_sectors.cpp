#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

dim2taylor V0(int order, const interval& r, const interval& phi);
dim2taylor V1(int order, const interval& r, const interval& phi);
dim2taylor V2(int order, const interval& r, const interval& phi);
dim2taylor V(int order, const interval& r, const interval& phi, 
   const interval& m1, const interval& m2);
dim2taylor Vhat(int order, const interval& r, const interval& phi, 
   const interval& m1, const interval& m2);
interval Vhat_div_r2_with_diff(const interval& r, 
   const interval& phi, const interval& m1, const interval& m2,
   int diff1, int diff2);
interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Computing bounds from Lemma 1" << endl;

   dim2taylor VV;
   interval R, phi, C1, C2, lma, aux, alpha, pi, left, right, val2;
   int i, j, order, N, M, flag_validity;

   pi = atan(interval(1))*interval(4);
   alpha = atan(interval(1)); //alpha = pi/4

   val2 = interval(2);
   R = interval(1)/interval(10000);
   lma = interval(3)/interval(4);
   C1 = interval(948597)/interval(100000);
   C2 = interval(189719)/interval(10000);

   cout << "alpha = " << alpha << endl;
   cout << "R = " << R << endl;
   cout << "C1 = " << C1 << endl;
   cout << "C2 = " << C2 << endl;

   cout << "#Checking J_0^+" << endl;
   left = -alpha/interval(2);
   right = alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(cos(val2*phi))+R*(C1+C2)/lma;
      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi,phi} < 0" << endl << endl;
   }

   cout << "#Checking J_0^-" << endl;
   left = pi/interval(2)-alpha/interval(2);
   right = pi/interval(2)+alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(cos(val2*phi))+R*(C1+C2)/lma;
      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi,phi} < 0" << endl << endl;
   }

   cout << "#Checking J_1^+" << endl;
   left = pi-alpha/interval(2);
   right = pi+alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(cos(val2*phi))+R*(C1+C2)/lma;
      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi,phi} < 0" << endl << endl;
   }

   cout << "#Checking J_1^-" << endl;
   left = interval(3)*pi/interval(2)-alpha/interval(2);
   right = interval(3)*pi/interval(2)+alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(cos(val2*phi))+R*(C1+C2)/lma;
      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi,phi} < 0" << endl << endl;
   }

   cout << "#Checking N_0" << endl;
   left = alpha/interval(2);
   right = pi/interval(2)-alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(sin(val2*phi))+R*C1*interval(2)/lma;

      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi} < 0" << endl << endl;
   }
   
   cout << "#Checking N_1" << endl;
   left = pi/interval(2)+alpha/interval(2);
   right = pi-alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(sin(val2*phi))+R*C1*interval(2)/lma;

      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi} < 0" << endl << endl;
   }
   
   cout << "#Checking N_2" << endl;
   left = pi+alpha/interval(2);
   right = interval(3)*pi/interval(2)-alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi  = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(sin(val2*phi))+R*C1*interval(2)/lma;

      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi} < 0" << endl << endl;
   }

   cout << "#Checking N_3" << endl;
   left = interval(3)*pi/interval(2)+alpha/interval(2);
   right = interval(2)*pi-alpha/interval(2);
   flag_validity = 0;
   N = 10;
   for(i = 0; i < N; i++)
   {
      phi = left+(right-left)*interval(i, i+1.)/interval(N);
      aux = -abs(sin(val2*phi))+R*C1*interval(2)/lma;

      if(Sup(aux) > 0)
      {
         cout << "Fail" << endl;
         cout << "phi = " << phi << endl;
         cout << "res = " << aux << endl;
         flag_validity = 1;
         break;
      }
      if(flag_validity == 1)
      {
         break;
      }
   }
   if(flag_validity == 0)
   {
      cout << "V_{phi} < 0" << endl << endl;
   }

   return 0;
}

dim2taylor V0(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   //r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));
   r3 = sqrt(1+2*tv[1]*cos(tv[2])+sqr(tv[1]));

   //res = sqr(tv[1])/interval(2)+tv[1]*cos(tv[2])+interval(1)/r3;
   res = sqr(tv[1])/2+tv[1]*cos(tv[2])+1/r3;

   return res;
}

dim2taylor V1(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   //r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));
   r3 = sqrt(1+2*tv[1]*cos(tv[2])+sqr(tv[1]));

   //res = -tv[1]*cos(tv[2])-interval(1)/r3;
   res = -tv[1]*cos(tv[2])-1/r3;

   return res;
}


dim2taylor V2(int order, const interval& r, const interval& phi)
{
   dim2taylor res, r3, r2;
   dim2taylor_vector tv;
   ivector iv(2);
   interval pi;
   
   iv[1] = r;
   iv[2] = phi;

   pi = atan(interval(1))*interval(4);

   tv = init_var(order, iv);

   //r2 = sqrt(interval(1)
   //   +interval(2)*tv[1]*cos(tv[2]+pi/interval(3))+sqr(tv[1]));
   r2 = sqrt(1+2*tv[1]*cos(tv[2]+pi/interval(3))+sqr(tv[1]));
   //r3 = sqrt(interval(1)+interval(2)*tv[1]*cos(tv[2])+sqr(tv[1]));
   r3 = sqrt(1+2*tv[1]*cos(tv[2])+sqr(tv[1]));

   //res = -tv[1]*cos(tv[2]-pi/interval(3))+interval(1)/r2-interval(1)/r3;
   res = -tv[1]*cos(tv[2]-pi/interval(3))+1/r2-1/r3;

   return res;
}

dim2taylor V(int order, const interval& r, const interval& phi, 
   const interval& m1, const interval& m2)
{
   dim2taylor res, r3, r2;
   dim2taylor_vector tv;
   ivector iv(2);
   
   iv[1] = r;
   iv[2] = phi;

   tv = init_var(order, iv);

   res = V0(order, r, phi)+m1*V1(order, r, phi)+m2*V2(order, r, phi)
      +interval(1)/tv[1];

   return res;
}

dim2taylor Vhat(int order, const interval& r, const interval& phi, 
   const interval& m1, const interval& m2)
{
   dim2taylor res, r3, r2;

   res = V0(order, r, phi)+m1*V1(order, r, phi)+m2*V2(order, r, phi);

   return res;
}

interval Vhat_div_r2_with_diff(const interval& r, 
   const interval& phi, const interval& m1, const interval& m2, 
   int diff1, int diff2)
{
   dim2taylor res, res2;
   interval restot;

   res = diff(Vhat(1+2+diff1+diff2, r, phi, m1, m2), diff1, diff2);

   res2 = remove_and_shift(res, 1, 2); //This removes a power r^2 factor from the
   restot = res2[0][0];
   //expression

   return restot;
}

interval evaluate_dim2taylor(const dim2taylor& V, const interval& x, 
   const interval & y)
{
   interval res(0), xi, yj;
   int i, j;

   xi = interval(1);
   yj = interval(1);
   for(i = 0; i <= V.order(); i++)
   {
      yj = interval(1);
      for(j = 0; j <= V.order()-i; j++)
      {
         res = res+V[i][j]*xi*yj;
         yj = yj*(y-y);
      }
      xi = xi*(x-x);
   }

   return res;
}
