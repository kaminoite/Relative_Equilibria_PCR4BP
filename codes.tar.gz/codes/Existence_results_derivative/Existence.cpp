#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"
#include "itaylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

interval eval_V0_r2(const interval& r, const interval& phi);
interval eval_V1_r2(const interval& r, const interval& phi);
interval eval_V2_r2(const interval& r, const interval& phi);
interval eval_V0_r2_phi(const interval& r, const interval& phi);
interval eval_V0_r_phi2(const interval& r, const interval& phi);
interval eval_V0_r_phi(const interval& r, const interval& phi);
interval eval_V1_r_phi(const interval& r, const interval& phi);
interval eval_V2_r_phi(const interval& r, const interval& phi);
interval eval_V2_r(const interval& r, const interval& phi);
interval evaluate_itaylor(const itaylor& V, const interval& x);

int main(int argc, char* argv[])
{
   cout << SetPrecision(14, 10);
   
   cout << endl << "#Existence results" << endl << endl;

   itaylor phi0, phi0_prime, aux_it;
   interval coef_m2, coef_m1, coef_0;
   itaylor x;
   interval delta, delta_prime, image_phi0, image_phi0_prime;
   interval r, phi, m1, m2, aux, pi;
   int i, order, N;

   N = 100;
   pi = atan(interval(1))*interval(4);

   r = interval(0, 1)/interval(1000);
   m1 = interval(0, 1)/interval(100);
   m2 = interval(0, 1)/interval(100);
   delta = interval(-724802, 724802)/interval(1000000);
   delta_prime = interval(-856695, 856695)/interval(100000);
   
   cout << "#Constants:" << endl;
   cout << "   R = " << r << endl;
   cout << "   m1 = " << m1 << endl;
   cout << "   m2 = " << m2 << endl;
   cout << "   delta = " << delta << endl;
   cout << "   delta' = " << delta_prime << endl;
   cout << endl;

   cout << "#Bounds for phi_0(r)=pi/2+r/2+r^3/48+";
   cout << "[ 0., 0.0001171998]r^4" << endl << endl;
   
   order = 4;

   x = itaylor(order, interval(0));
   phi0 = pi/interval(2)+x/interval(2)+sqr(x)*x/interval(48)+sqr(sqr(x))*
      interval(0, 118)/interval(1000000);
   phi0_prime = interval(1)/interval(2)+sqr(x)/interval(16)+x*(sqr(x))*
      interval(0, 470)/interval(1000000);

   image_phi0 = evaluate_itaylor(phi0, r);
   image_phi0 = image_phi0+m2*delta;
  
   image_phi0_prime = evaluate_itaylor(phi0_prime, r);
   image_phi0_prime = image_phi0_prime+m2*delta_prime;

   coef_m1 = eval_V1_r2(r, image_phi0)
      +eval_V1_r_phi(r, image_phi0)*image_phi0_prime; 

   coef_m2 = eval_V2_r2(r, image_phi0)
      +eval_V0_r2_phi(r, image_phi0)*delta //These derivatives are correct because are wrt m2
      +eval_V0_r_phi2(r, image_phi0)*delta*image_phi0_prime
      +eval_V0_r_phi(r, image_phi0)*delta_prime
      +eval_V2_r_phi(r, image_phi0)*image_phi0_prime;

   cout << "   " << coef_m1 << "m_1+" << coef_m2 << "m_2+2m_1/r^3" << endl << endl;

   cout << "#Bounds for phi_0(r)=3pi/2-r/2-r^3/48-";
   cout << "[ 0., 0.0001171998]r^4" << endl << endl;
   
   order = 4;

   x = itaylor(order, interval(0));
   phi0 = interval(3)*pi/interval(2)-x/interval(2)
      -sqr(x)*x/interval(48)-sqr(sqr(x))*
      interval(0, 118)/interval(1000000);
   phi0_prime = -interval(1)/interval(2)-sqr(x)/interval(16)-x*(sqr(x))*
      interval(0, 470)/interval(1000000);

   image_phi0 = evaluate_itaylor(phi0, r);
   image_phi0 = image_phi0+interval(0, 1)*m2*delta;
  
   image_phi0_prime = evaluate_itaylor(phi0_prime, r);
   image_phi0_prime = image_phi0_prime+interval(0, 1)*m2*delta_prime;

   coef_m1 = eval_V1_r2(r, image_phi0)
      +eval_V1_r_phi(r, image_phi0)*image_phi0_prime; 

   coef_m2 = eval_V2_r2(r, image_phi0)
      +eval_V0_r2_phi(r, image_phi0)*delta
      +eval_V0_r_phi2(r, image_phi0)*delta*image_phi0_prime
      +eval_V0_r_phi(r, image_phi0)*delta_prime
      +eval_V2_r_phi(r, image_phi0)*image_phi0_prime;

   cout << "   " << coef_m1 << "m_1+" << coef_m2 << "m_2+2m_1/r^3" << endl << endl;

   cout << "#Bounds for phi_0(r)=0" << endl << endl;
   
   order = 4;

   image_phi0 = m2*delta;
   aux = eval_V0_r2(r, image_phi0)+
      m1*eval_V1_r2(r, image_phi0)+
      m2*eval_V2_r2(r, image_phi0)+
      (eval_V0_r_phi(r, image_phi0)+
      m1*eval_V1_r_phi(r, image_phi0)+
      m2*eval_V2_r_phi(r, image_phi0))*m2*delta_prime;

   cout << "   " << aux << "+2m_1/r^3" << endl << endl;

   cout << "#Bounds for phi_0(r)=pi" << endl << endl;
   
   order = 4;
   
   image_phi0 = pi+m2*delta;
   aux = eval_V0_r2(r, image_phi0)+
      m1*eval_V1_r2(r, image_phi0)+
      m2*eval_V2_r2(r, image_phi0)+
      (eval_V0_r_phi(r, image_phi0)+
      m1*eval_V1_r_phi(r, image_phi0)+
      m2*eval_V2_r_phi(r, image_phi0))*m2*delta_prime;

   cout << "   " << aux << "+2m_1/r^3" << endl << endl;

   return 0;
}

interval eval_V0_r2(const interval& r, const interval& phi)
{
   interval res, r3;

   res = interval(0);

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = interval(1)-interval(1)/(sqr(r3)*r3)+interval(3)*sqr(r+cos(phi))/
      (sqr(sqr(r3))*r3);

   return res;
}

interval eval_V1_r2(const interval& r, const interval& phi)
{
   interval res, r3;

   res = interval(0);

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = interval(1)/(sqr(r3)*r3)-interval(3)*sqr(r+cos(phi))/
      (sqr(sqr(r3))*r3);

   return res;
}

interval eval_V2_r2(const interval& r, const interval& phi)
{
   interval res, pi, r2, r3;

   pi = atan(interval(1))*interval(4);

   r2 = sqrt(interval(1)+interval(2)*r*cos(phi+pi/interval(3))+sqr(r));
   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+sqr(r));

   res = power(r2, -3)+power(r2, -5)
      *(-interval(3)*sqrt(interval(3))/interval(4)*
      sin(phi)*(cos(phi)-sqrt(interval(3))*sin(phi)+interval(2)*r)+interval(3)/
      interval(4)*cos(phi)*(cos(phi)-sqrt(interval(3))*sin(phi)+interval(2)*r)
      +interval(3)/interval(2)*r*(cos(phi)-sqrt(interval(3))*sin(phi)
      +interval(2)*r))
      +power(r3, -3)-power(r3, -5)*interval(3)*sqr(r+cos(phi));

   res = interval(1)/(sqr(r3)*r3)-interval(3)*sqr(cos(phi)+r)/(sqr(sqr(r3))*r3)-interval(1)/(sqr(r2)*r2)+
      (sqrt(interval(3))/interval(2)*sin(phi)-cos(phi)/interval(2)-r)*(cos(phi+pi/interval(3))+r)*
      interval(-3)/(sqr(sqr(r2))*r2);
   return res;
}

interval eval_V0_r2_phi(const interval& r, const interval& phi)
{
   interval res, r3, s, c;

   res = interval(0);

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);
   c = cos(phi);
   s = sin(phi);

   res = interval(3)*s*(c*c*r+interval(2)*(c*r*r+r*r*r-c)-
   interval(3)*r)/(r3*r3*r3*r3*r3*r3*r3);

   return res;
}
interval eval_V0_r_phi2(const interval& r, const interval& phi)
{
   interval res, r3;

   res = interval(0);

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = -cos(phi)+cos(phi)/(r3*r3*r3)
      +(-interval(3)*(r+cos(phi))*r*cos(phi)+interval(6)*
      sqr(sin(phi))*r)/(r3*r3*r3*r3*r3)
      +(interval(15)*sqr(r*sin(phi))*(cos(phi)+r))/(r3*r3*r3*r3*r3*r3*r3);

   return res;
}

interval eval_V0_r_phi(const interval& r, const interval& phi)
{
   interval res, r3;

   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+r*r);

   res = -sin(phi)*(interval(1)-interval(1)/(r3*r3*r3))-r*sin(phi)*
      (cos(phi)+r)/(r3*r3*r3*r3*r3);

   return res;
}

interval eval_V1_r_phi(const interval& r, const interval& phi)
{
   interval res;

   res = -eval_V0_r_phi(r, phi);

   return res;
}

interval eval_V2_r_phi(const interval& r, const interval& phi)
{
   interval res, pi;

   pi = atan(interval(1))*interval(4);

   res = -eval_V0_r_phi(r, phi)+
      eval_V0_r_phi(r, phi+pi/interval(3));

   return res;
}

interval eval_V2_r(const interval& r, const interval& phi)
{
   interval res, pi, r2, r3;

   pi = atan(interval(1))*interval(4);

   r2 = sqrt(interval(1)+interval(2)*r*cos(phi+pi/interval(3))+sqr(r));
   r3 = sqrt(interval(1)+interval(2)*r*cos(phi)+sqr(r));

   res = -sqrt(interval(3))/interval(2)*sin(phi)
      *(interval(1)-interval(1)/(r2*r2*r2))-cos(phi)/interval(2)*
      (interval(1)+interval(1)/(r2*r2*r2))-r/(r2*r2*r2)+(cos(phi)+r)/
      (r3*r3*r3);

   return res;
}

interval evaluate_itaylor(const itaylor& V, const interval& x)
{
   itaylor VV;
   interval res(0), xi;
   int i;

   VV = V;
   xi = interval(1);
   for(i = 0; i <= VV.order(); i++)
   {
      res = res+VV[i]*xi;
      xi = xi*(x-x);
   }

   return res;
}
