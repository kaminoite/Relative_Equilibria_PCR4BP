#include "interval.hpp"

#include <iostream>
#include <string>
#include <queue>
#include <fstream>
#include <cassert>
#include <vector>
#include "dim2taylor.hpp"

clock_t startm, stopm;
#define START if ( (startm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define STOP if ( (stopm = clock()) == -1) {printf("Error calling clock");exit(1);}
#define PRINTTIME printf("# %6.3f seconds used by the processor.\n", ((double)stopm-startm)/CLOCKS_PER_SEC);

using namespace cxsc;
using namespace std;
using namespace taylor;

int main(int argc, char* argv[])
{
   cout << SetPrecision(7, 5);
   

   interval R, C1, C2, diff, der2, t, phip, res;
   int order;


   //if f(x)=sqrt(1-x^2), then 
   //f''(x)=-(1-x^2)^{-1/2}-x^2(1-x^2)^{-3/2}
 
   diff = interval(3)/interval(4);
   C1 = interval(1304848)/interval(100000);
   C2 = interval(260970)/interval(10000);
   R = interval(0, 1)/interval(100);
   
   cout << endl;
   cout << "C1 = " << C1 << endl;
   cout << "C2 = " << C2 << endl;
   cout << "R  = " << R << endl ;
   cout << endl << "#Computing bounds for phi'" << endl << endl;
   
   t = interval(-1, 1)*interval(2)*C1*R/diff;

   der2 = -pow(interval(1)-sqr(t), interval(-1)/interval(2))-sqr(t)*
      pow(interval(1)-sqr(t), interval(-3)/interval(2));
 
   diff = interval(3, 12)/interval(4);

   phip = (interval(3)*C1+C2)/(diff*(interval(1)-der2*sqr(t))-(C1+C2)*R);

   cout << "\t|r| <= R = " << R << endl << endl;

   cout << "\t|phi'(r)| <= " << Sup(abs(phip)) << endl << endl;

   return 0;
}
